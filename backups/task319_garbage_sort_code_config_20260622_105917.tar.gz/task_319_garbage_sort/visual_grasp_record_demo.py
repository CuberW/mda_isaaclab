"""Head-camera visual grasp demo for task 319.

This entrypoint uses the same phase-one style scene as the ROS/Nav2 preview:
Kuavo S62, a table, four open bins, ten textured YCB trash objects, the attached
right gripper, and the robot head RGB-D camera.  The perception chain consumes
only the head camera images:

head RGB-D -> YOLO masks -> GLM VLM object/category labels -> GraspNet candidates
-> optional right-arm grasp/lift/hold.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw

WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))
for source_dir in (
    WORKSPACE_ROOT / "IsaacLab/source/isaaclab",
    WORKSPACE_ROOT / "IsaacLab/source/isaaclab_assets",
    WORKSPACE_ROOT / "IsaacLab/source/isaaclab_tasks",
):
    if source_dir.exists() and str(source_dir) not in sys.path:
        sys.path.insert(0, str(source_dir))

from isaaclab.app import AppLauncher


def parse_xyz(value: str) -> tuple[float, float, float]:
    parts = [float(item.strip()) for item in value.split(",")]
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("Expected x,y,z.")
    return (parts[0], parts[1], parts[2])


parser = argparse.ArgumentParser(description="Task 319 head-camera visual grasp demo.")
parser.add_argument("--num_envs", type=int, default=1)
parser.add_argument("--num_cycles", type=int, default=0, help="Number of perception cycles. 0 loops until Isaac closes.")
parser.add_argument("--warmup_steps", type=int, default=100)
parser.add_argument("--cycle_interval_steps", type=int, default=240)
parser.add_argument("--output_dir", default="task_319_garbage_sort/output/head_camera_grasp_records")
parser.add_argument("--robot_pos", type=parse_xyz, default=(0.53, 0.0, 0.0), help="Robot root position x,y,z.")
parser.add_argument("--robot_yaw", type=float, default=0.0, help="Robot yaw in radians; 0 faces the +X table direction.")
parser.add_argument("--head_yaw", type=float, default=0.0)
parser.add_argument("--head_pitch", type=float, default=0.0)
parser.add_argument("--yolo_weights", default="models/yolo/yolov8m-seg.pt")
parser.add_argument("--yolo_conf", type=float, default=0.08)
parser.add_argument("--yolo_imgsz", type=int, default=640)
parser.add_argument("--skip_yolo", action="store_true")
parser.add_argument("--skip_vlm", action="store_true", help="Debug only: skip GLM VLM and use weak YOLO labels.")
parser.add_argument("--vlm_model", default="glm-5v-turbo")
parser.add_argument("--vlm_endpoint", default="https://open.bigmodel.cn/api/paas/v4/chat/completions")
parser.add_argument("--vlm_min_conf", type=float, default=0.35)
parser.add_argument("--max_vlm_instances", type=int, default=8)
parser.add_argument("--target_category", default="", help="Optional target category: 可回收物/厨余垃圾/其他垃圾/有害垃圾.")
parser.add_argument("--target_object_name", default="", help="Optional substring match against the VLM object name.")
parser.add_argument("--skip_graspnet", action="store_true")
parser.add_argument("--use_centroid_fallback", action="store_true", help="Use a local point-cloud top-down grasp if GraspNet has no valid candidate.")
parser.add_argument("--disable_depth_component_fallback", action="store_true", help="Disable head-depth tabletop component fallback masks.")
parser.add_argument("--graspnet_repo", default="third_party/graspnet-baseline")
parser.add_argument("--graspnet_checkpoint", default="models/graspnet-rs/checkpoint-rs.tar")
parser.add_argument("--graspnet_num_point", type=int, default=8000)
parser.add_argument("--graspnet_max_draw", type=int, default=80)
parser.add_argument("--execute_grasp", action="store_true")
parser.add_argument("--record_debug", action="store_true", help="Keep explicit FSM/debug metadata in each cycle directory.")
parser.add_argument("--enable_sort_nav", action="store_true", help="After a verified grasp, drive to the hard-coded matching bin and drop.")
parser.add_argument("--trajectory_steps", type=int, default=220)
parser.add_argument("--grasp_steps", type=int, default=90)
parser.add_argument("--lift_steps", type=int, default=160)
parser.add_argument("--hold_steps", type=int, default=180)
parser.add_argument("--drop_steps", type=int, default=120)
parser.add_argument("--max_joint_step", type=float, default=0.018)
parser.add_argument("--pregrasp_offset", type=float, default=0.08)
parser.add_argument("--lift_height", type=float, default=0.18)
parser.add_argument("--nav_max_steps_per_waypoint", type=int, default=1800)
parser.add_argument("--nav_position_tolerance", type=float, default=0.08)
parser.add_argument("--nav_yaw_tolerance", type=float, default=0.08)
parser.add_argument("--nav_linear_gain", type=float, default=0.9)
parser.add_argument("--nav_angular_gain", type=float, default=2.4)
parser.add_argument("--nav_max_linear_speed", type=float, default=0.35)
parser.add_argument("--nav_max_angular_speed", type=float, default=0.8)
parser.add_argument("--wheel_radius", type=float, default=0.09)
parser.add_argument("--track_width", type=float, default=0.52)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()
args_cli.enable_cameras = True

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import torch

try:
    import warp as wp

    wp.init()
except Exception:
    wp = None

import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import Articulation, ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers import DifferentialIKController, DifferentialIKControllerCfg
from isaaclab.managers import SceneEntityCfg
from isaaclab.markers import VisualizationMarkers
from isaaclab.markers.config import FRAME_MARKER_CFG
from isaaclab.scene import InteractiveScene, InteractiveSceneCfg
from isaaclab.sensors import CameraCfg
from isaaclab.sim import SimulationContext
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.utils.math import matrix_from_quat, quat_from_matrix, subtract_frame_transforms

from task_319_garbage_sort.grasp_pipeline.execution.gripper_control import AttachedParallelGripper
from task_319_garbage_sort.grasp_pipeline.grasping.grasp_selector import select_best_grasp
from task_319_garbage_sort.grasp_pipeline.grasping.mask_filter import clamp_width, filter_grasps_by_mask
from task_319_garbage_sort.grasp_pipeline.grasping.graspnet_wrapper import GraspNetWrapper
from task_319_garbage_sort.grasp_pipeline.perception.depth_utils import masked_depth_center_world
from task_319_garbage_sort.grasp_pipeline.perception.glm_vlm_classifier import GlmVlmClassifier, VlmClassification
from task_319_garbage_sort.grasp_pipeline.types import GraspCandidates, PerceivedObject, SelectedGrasp
from task_319_garbage_sort.gripper_robot_urdf import ensure_kuavo_with_gripper_urdf


_YOLO_MODEL: Any | None = None
_GRASPNET_WRAPPER: GraspNetWrapper | None = None
_VLM_CLASSIFIER: GlmVlmClassifier | None = None

ROOT_DIR = WORKSPACE_ROOT
GRIPPER_URDF = ROOT_DIR / "task_319_garbage_sort/two_finger_gripper.urdf"
KUAVO_BASE_URDF = ROOT_DIR / "kuavo-ros-opensource/src/kuavo_assets/models/biped_s62/urdf/biped_s62.urdf"
KUAVO_URDF = ensure_kuavo_with_gripper_urdf(KUAVO_BASE_URDF, GRIPPER_URDF)
YCB_AXIS_ALIGNED_DIR = f"{ISAAC_NUCLEUS_DIR}/Props/YCB/Axis_Aligned"
YCB_AXIS_ALIGNED_PHYSICS_DIR = f"{ISAAC_NUCLEUS_DIR}/Props/YCB/Axis_Aligned_Physics"

TABLE_TOP_CENTER_Z = 0.51
TABLE_TOP_THICKNESS = 0.06
TABLE_SURFACE_Z = TABLE_TOP_CENTER_Z + TABLE_TOP_THICKNESS / 2.0
TRASH_VISUAL_CLEARANCE = 0.002
ROBOT_STABILIZED_BASE_Z = 0.0
RIGHT_ARM_JOINT_EXPR = "zarm_r[1-7]_joint"
RIGHT_EE_BODY = "zarm_r7_end_effector"
WHEEL_JOINTS = [
    "wheel_left_front_joint",
    "wheel_left_behind_joint",
    "wheel_right_front_joint",
    "wheel_right_behind_joint",
]
ROT_X_90 = (0.70710678, 0.70710678, 0.0, 0.0)

YCB_LOCAL_MIN_Y = {
    "003_cracker_box": -0.106719,
    "004_sugar_box": -0.088127,
    "005_tomato_soup_can": -0.050927,
    "006_mustard_bottle": -0.095650,
    "010_potted_meat_can": -0.041772,
    "011_banana": -0.019325,
    "021_bleach_cleanser": -0.125290,
    "025_mug": -0.040652,
    "040_large_marker": -0.010500,
    "061_foam_brick": -0.025596,
}
YCB_VISUAL_RUNTIME_MASSES = {
    "trash_banana_0": 0.08,
    "trash_potted_meat_can_0": 0.09,
    "trash_bleach_cleanser_0": 0.18,
    "trash_large_marker_0": 0.02,
    "trash_foam_brick_0": 0.02,
    "trash_mug_0": 0.12,
}
TARGET_PRIORITY = {"有害垃圾": 0, "厨余垃圾": 1, "可回收物": 2, "其他垃圾": 3}
MAX_TARGET_MASK_FRACTION = 0.20
MAX_TARGET_BBOX_AREA_FRACTION = 0.45
MIN_TARGET_MASK_PIXELS = 120
TRASH_SCENE_OBJECTS = [
    ("trash_00", "trash_cracker_box_0"),
    ("trash_01", "trash_sugar_box_0"),
    ("trash_02", "trash_tomato_soup_can_0"),
    ("trash_03", "trash_mustard_bottle_0"),
    ("trash_04", "trash_banana_0"),
    ("trash_05", "trash_potted_meat_can_0"),
    ("trash_06", "trash_bleach_cleanser_0"),
    ("trash_07", "trash_large_marker_0"),
    ("trash_08", "trash_foam_brick_0"),
    ("trash_09", "trash_mug_0"),
]
BIN_Y_BY_CATEGORY = {
    "可回收物": -0.72,
    "可回收垃圾": -0.72,
    "厨余垃圾": -0.24,
    "有害垃圾": 0.24,
    "其他垃圾": 0.72,
}
BIN_NAME_BY_CATEGORY = {
    "可回收物": "recycle",
    "可回收垃圾": "recycle",
    "厨余垃圾": "kitchen",
    "有害垃圾": "hazard",
    "其他垃圾": "other",
}
TABLE_APPROACH_POSE = (0.53, 0.0, 0.0)
SIDE_CORRIDOR_Y = 1.35
BIN_DRIVE_X = 3.55
TABLE_X_LIMITS = (0.92, 2.68)
TABLE_Y_LIMITS = (-0.42, 0.42)
GRIPPER_TCP_OFFSET_M = np.array([0.075, 0.0, 0.0], dtype=np.float32)
RIGHT_ARM_TARGET_Y_BOUNDS = (-0.46, 0.08)
RIGHT_ARM_PREFERRED_TARGET_Y = -0.16
SCENE_OBJECT_WASTE_CATEGORY = {
    "trash_00": "可回收物",
    "trash_01": "可回收物",
    "trash_02": "可回收物",
    "trash_03": "可回收物",
    "trash_04": "厨余垃圾",
    "trash_05": "厨余垃圾",
    "trash_06": "有害垃圾",
    "trash_07": "有害垃圾",
    "trash_08": "其他垃圾",
    "trash_09": "其他垃圾",
}
SCENE_GRASP_PRIORITY = {
    "trash_07": 0,  # large marker: small, horizontal, and easy to pinch.
    "trash_08": 1,
    "trash_05": 2,
    "trash_02": 3,
    "trash_09": 4,
    "trash_06": 5,
}


@dataclass(slots=True)
class YoloInstance:
    index: int
    yolo_label: str
    yolo_confidence: float
    bbox_xyxy: tuple[float, float, float, float]
    mask: np.ndarray
    vlm: VlmClassification | None = None
    center_3d: np.ndarray | None = None
    source: str = "yolo"
    scene_key: str | None = None
    scene_object_name: str | None = None
    component_score: float = 0.0


TASK_STATE_NAMES = [
    "REST",
    "BASE_TO_TABLE",
    "STATIC_PERCEPT",
    "PLAN_GRASP",
    "PRE_GRASP",
    "GRASP",
    "LIFT",
    "VERIFY_HOLD",
    "NAV_TO_BIN",
    "DROP",
    "RETURN_HOME",
    "NEXT_OBJECT",
    "DONE",
    "RECOVER",
]
TASK_STATE_TO_ID = {name: idx for idx, name in enumerate(TASK_STATE_NAMES)}


if wp is not None:

    @wp.kernel
    def _task_fsm_kernel(
        dt: wp.array(dtype=float),
        state: wp.array(dtype=int),
        wait_time: wp.array(dtype=float),
        requested_state: wp.array(dtype=int),
        gripper_state: wp.array(dtype=float),
    ):
        tid = wp.tid()
        requested = requested_state[tid]
        if requested >= 0:
            state[tid] = requested
            wait_time[tid] = 0.0
            requested_state[tid] = -1
        current = state[tid]
        if current == 5 or current == 6 or current == 7 or current == 8 or current == 9:
            gripper_state[tid] = -1.0
        else:
            gripper_state[tid] = 1.0
        wait_time[tid] = wait_time[tid] + dt[tid]


class Task319StateTracker:
    """Small state tracker mirroring IsaacLab's Warp FSM pattern for traceable task execution."""

    def __init__(self, dt: float, device: str | torch.device) -> None:
        self.dt = float(dt)
        self.device = device
        self.trace: list[dict[str, Any]] = []
        self._warp_enabled = wp is not None
        if self._warp_enabled:
            try:
                self._dt = torch.full((1,), self.dt, device=device)
                self._state = torch.zeros((1,), dtype=torch.int32, device=device)
                self._wait = torch.zeros((1,), dtype=torch.float32, device=device)
                self._requested = torch.full((1,), -1, dtype=torch.int32, device=device)
                self._gripper = torch.ones((1,), dtype=torch.float32, device=device)
                self._dt_wp = wp.from_torch(self._dt, wp.float32)
                self._state_wp = wp.from_torch(self._state, wp.int32)
                self._wait_wp = wp.from_torch(self._wait, wp.float32)
                self._requested_wp = wp.from_torch(self._requested, wp.int32)
                self._gripper_wp = wp.from_torch(self._gripper, wp.float32)
            except Exception as exc:
                self._warp_enabled = False
                self.trace.append({"state": "REST", "event": "warp_disabled", "reason": repr(exc)})
        self.state_name = "REST"

    @property
    def warp_enabled(self) -> bool:
        return self._warp_enabled

    def enter(self, state_name: str, **metadata: Any) -> None:
        if state_name not in TASK_STATE_TO_ID:
            raise ValueError(f"Unknown task state: {state_name}")
        self.state_name = state_name
        if self._warp_enabled:
            self._requested[0] = TASK_STATE_TO_ID[state_name]
            self.tick()
        event = {"state": state_name, "event": "enter", **metadata}
        if self._warp_enabled:
            event["wait_time_s"] = float(self._wait[0].detach().cpu())
            event["gripper_command"] = float(self._gripper[0].detach().cpu())
        self.trace.append(event)

    def tick(self) -> None:
        if not self._warp_enabled:
            return
        wp.launch(
            kernel=_task_fsm_kernel,
            dim=1,
            inputs=[self._dt_wp, self._state_wp, self._wait_wp, self._requested_wp, self._gripper_wp],
            device=self.device,
        )

    def event(self, name: str, **metadata: Any) -> None:
        self.trace.append({"state": self.state_name, "event": name, **metadata})


def quat_wxyz_from_yaw(yaw: float) -> tuple[float, float, float, float]:
    return (math.cos(0.5 * yaw), 0.0, 0.0, math.sin(0.5 * yaw))


def yaw_from_quat_wxyz(q: Any) -> float:
    w, x, y, z = (float(q[0]), float(q[1]), float(q[2]), float(q[3]))
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def wrap_to_pi(angle: float) -> float:
    return math.atan2(math.sin(angle), math.cos(angle))


def canonical_category(category: str | None) -> str:
    if not category:
        return "其他垃圾"
    if category in BIN_Y_BY_CATEGORY:
        return "可回收物" if category == "可回收垃圾" else category
    if "有害" in category:
        return "有害垃圾"
    if "厨余" in category or "湿垃圾" in category:
        return "厨余垃圾"
    if "回收" in category:
        return "可回收物"
    return "其他垃圾"


def category_for_scene_key(scene_key: str | None) -> str:
    return SCENE_OBJECT_WASTE_CATEGORY.get(scene_key or "", "其他垃圾")


def reachability_score(center_3d: np.ndarray | None) -> tuple[int, float]:
    if center_3d is None:
        return (1, 1.0)
    dx = float(center_3d[0] - args_cli.robot_pos[0])
    dy = float(center_3d[1] - args_cli.robot_pos[1])
    dz = float(center_3d[2])
    reachable = (
        0.35 <= dx <= 0.92
        and RIGHT_ARM_TARGET_Y_BOUNDS[0] <= dy <= RIGHT_ARM_TARGET_Y_BOUNDS[1]
        and TABLE_SURFACE_Z + 0.015 <= dz <= TABLE_SURFACE_Z + 0.35
    )
    preferred_dx = 0.55
    right_arm_side_penalty = 1.5 * max(0.0, dy - RIGHT_ARM_TARGET_Y_BOUNDS[1])
    return (0 if reachable else 1, abs(dx - preferred_dx) + 0.45 * abs(dy - RIGHT_ARM_PREFERRED_TARGET_Y) + right_arm_side_penalty)


def uniform_scale(scale: float) -> tuple[float, float, float]:
    return (scale, scale, scale)


def ycb_table_pos_from_min_y(x: float, y: float, name: str, scale: float = 1.0) -> tuple[float, float, float]:
    return (x, y, TABLE_SURFACE_Z + TRASH_VISUAL_CLEARANCE - YCB_LOCAL_MIN_Y[name] * scale)


def high_friction_material() -> sim_utils.RigidBodyMaterialCfg:
    return sim_utils.RigidBodyMaterialCfg(
        static_friction=1.45,
        dynamic_friction=1.10,
        restitution=0.0,
        friction_combine_mode="max",
        restitution_combine_mode="min",
    )


def contact_material(static_friction: float, dynamic_friction: float, restitution: float = 0.01) -> sim_utils.RigidBodyMaterialCfg:
    return sim_utils.RigidBodyMaterialCfg(
        static_friction=static_friction,
        dynamic_friction=dynamic_friction,
        restitution=restitution,
        friction_combine_mode="max",
        restitution_combine_mode="min",
    )


WOOD_MATERIAL = contact_material(0.72, 0.55, 0.02)
BIN_PLASTIC_MATERIAL = contact_material(0.85, 0.62, 0.02)
PAPER_MATERIAL = contact_material(1.05, 0.85, 0.01)
PLASTIC_MATERIAL = contact_material(0.62, 0.45, 0.035)
METAL_MATERIAL = contact_material(0.42, 0.30, 0.05)
FOOD_SKIN_MATERIAL = contact_material(0.95, 0.72, 0.02)


def colored_surface(color: tuple[float, float, float]) -> sim_utils.PreviewSurfaceCfg:
    return sim_utils.PreviewSurfaceCfg(diffuse_color=color, roughness=0.78)


def semantic_tags(semantic_class: str) -> list[tuple[str, str]]:
    return [("class", semantic_class)]


def rigid_props() -> sim_utils.RigidBodyPropertiesCfg:
    return sim_utils.RigidBodyPropertiesCfg(
        rigid_body_enabled=True,
        linear_damping=0.08,
        angular_damping=0.12,
        max_depenetration_velocity=1.5,
        solver_position_iteration_count=12,
        solver_velocity_iteration_count=4,
    )


def static_rigid_props() -> sim_utils.RigidBodyPropertiesCfg:
    return sim_utils.RigidBodyPropertiesCfg(
        rigid_body_enabled=True,
        kinematic_enabled=True,
        disable_gravity=True,
        linear_damping=0.0,
        angular_damping=0.0,
        max_depenetration_velocity=1.0,
        solver_position_iteration_count=8,
        solver_velocity_iteration_count=2,
    )


def collision_props(contact_offset: float = 0.003) -> sim_utils.CollisionPropertiesCfg:
    return sim_utils.CollisionPropertiesCfg(collision_enabled=True, contact_offset=contact_offset, rest_offset=0.0)


def cuboid_rigid(
    name: str,
    size: tuple[float, float, float],
    pos: tuple[float, float, float],
    mass: float,
    color: tuple[float, float, float],
    semantic_class: str,
    *,
    static: bool = False,
    material: sim_utils.RigidBodyMaterialCfg | None = None,
    contact_offset: float = 0.003,
) -> RigidObjectCfg:
    return RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{name}",
        spawn=sim_utils.CuboidCfg(
            size=size,
            rigid_props=static_rigid_props() if static else rigid_props(),
            mass_props=sim_utils.MassPropertiesCfg(mass=mass),
            collision_props=collision_props(contact_offset),
            physics_material=material or high_friction_material(),
            visual_material=colored_surface(color),
            semantic_tags=semantic_tags(semantic_class),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=pos),
    )


def usd_rigid(
    name: str,
    usd_path: Path | str,
    pos: tuple[float, float, float],
    scale: tuple[float, float, float],
    mass: float,
    material: sim_utils.RigidBodyMaterialCfg,
    semantic_class: str,
    *,
    rot: tuple[float, float, float, float] = (1.0, 0.0, 0.0, 0.0),
    contact_offset: float = 0.002,
    apply_runtime_physics: bool = True,
) -> RigidObjectCfg:
    return RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{name}",
        spawn=sim_utils.UsdFileCfg(
            usd_path=str(usd_path),
            scale=scale,
            rigid_props=rigid_props() if apply_runtime_physics else None,
            mass_props=sim_utils.MassPropertiesCfg(mass=mass) if apply_runtime_physics else None,
            collision_props=collision_props(contact_offset) if apply_runtime_physics else None,
            semantic_tags=semantic_tags(semantic_class),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=pos, rot=rot),
    )


def wheel_actuator_cfg() -> ImplicitActuatorCfg:
    if args_cli.enable_sort_nav:
        return ImplicitActuatorCfg(
            joint_names_expr=["wheel_.*_joint"],
            effort_limit_sim=35.0,
            velocity_limit_sim=25.0,
            stiffness=0.0,
            damping=18.0,
        )
    return ImplicitActuatorCfg(
        joint_names_expr=["wheel_.*_joint"],
        effort_limit_sim=350.0,
        velocity_limit_sim=0.05,
        stiffness=5000.0,
        damping=650.0,
    )


KUAVO_HEAD_GRASP_CFG = ArticulationCfg(
    prim_path="{ENV_REGEX_NS}/Kuavo62",
    spawn=sim_utils.UrdfFileCfg(
        asset_path=str(KUAVO_URDF),
        fix_base=not args_cli.enable_sort_nav,
        merge_fixed_joints=False,
        link_density=1000.0,
        collision_from_visuals=True,
        collider_type="convex_hull",
        self_collision=False,
        rigid_props=sim_utils.RigidBodyPropertiesCfg(
            rigid_body_enabled=True,
            linear_damping=0.08,
            angular_damping=0.12,
            max_depenetration_velocity=1.0,
            solver_position_iteration_count=16,
            solver_velocity_iteration_count=4,
        ),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            fix_root_link=not args_cli.enable_sort_nav,
            enabled_self_collisions=False,
            solver_position_iteration_count=16,
            solver_velocity_iteration_count=4,
        ),
        joint_drive=sim_utils.UrdfConverterCfg.JointDriveCfg(
            target_type="position",
            gains=sim_utils.UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=140.0, damping=16.0),
        ),
    ),
    init_state=ArticulationCfg.InitialStateCfg(
        pos=args_cli.robot_pos,
        rot=quat_wxyz_from_yaw(args_cli.robot_yaw),
        joint_pos={
            "knee_joint": 0.0,
            "leg_joint": 0.0,
            "waist_pitch_joint": 0.0,
            "waist_yaw_joint": 0.0,
            "zhead_1_joint": args_cli.head_yaw,
            "zhead_2_joint": args_cli.head_pitch,
            "zarm_l2_joint": 0.30,
            "zarm_l4_joint": -0.6,
            "zarm_r2_joint": 0.30,
            "zarm_r4_joint": -0.6,
            "left_finger_joint": 0.030,
            "right_finger_joint": 0.030,
        },
        joint_vel={".*": 0.0},
    ),
    actuators={
        "wheels": wheel_actuator_cfg(),
        "locked_stance": ImplicitActuatorCfg(
            joint_names_expr=["knee_joint", "leg_joint"],
            effort_limit_sim=900.0,
            velocity_limit_sim=0.1,
            stiffness=4500.0,
            damping=520.0,
        ),
        "locked_torso": ImplicitActuatorCfg(
            joint_names_expr=["waist_.*_joint"],
            effort_limit_sim=450.0,
            velocity_limit_sim=0.1,
            stiffness=3200.0,
            damping=380.0,
        ),
        "locked_left_arm": ImplicitActuatorCfg(
            joint_names_expr=["zarm_l[1-7]_joint"],
            effort_limit_sim=180.0,
            velocity_limit_sim=0.1,
            stiffness=2400.0,
            damping=260.0,
        ),
        "right_arm": ImplicitActuatorCfg(
            joint_names_expr=[RIGHT_ARM_JOINT_EXPR],
            effort_limit_sim=220.0,
            velocity_limit_sim=3.0,
            stiffness=1100.0,
            damping=110.0,
        ),
        "locked_head": ImplicitActuatorCfg(
            joint_names_expr=["zhead_[12]_joint"],
            effort_limit_sim=60.0,
            velocity_limit_sim=0.1,
            stiffness=900.0,
            damping=120.0,
        ),
        "right_gripper": ImplicitActuatorCfg(
            joint_names_expr=[".*finger_joint"],
            effort_limit_sim=60.0,
            velocity_limit_sim=0.35,
            stiffness=1200.0,
            damping=90.0,
        ),
    },
)


@configclass
class HeadCameraGraspSceneCfg(InteractiveSceneCfg):
    ground = AssetBaseCfg(
        prim_path="/World/defaultGroundPlane",
        spawn=sim_utils.GroundPlaneCfg(size=(12.0, 12.0), physics_material=high_friction_material(), color=(0.35, 0.36, 0.34)),
    )
    dome_light = AssetBaseCfg(prim_path="/World/Light", spawn=sim_utils.DomeLightCfg(intensity=2500.0, color=(0.82, 0.86, 0.9)))
    robot: ArticulationCfg = KUAVO_HEAD_GRASP_CFG

    table_top = cuboid_rigid("sorting_table_top", (1.80, 0.90, TABLE_TOP_THICKNESS), (1.80, 0.0, TABLE_TOP_CENTER_Z), 60.0, (0.48, 0.36, 0.24), "table", static=True, material=WOOD_MATERIAL)
    table_leg_fl = cuboid_rigid("sorting_table_leg_fl", (0.07, 0.07, 0.48), (0.96, -0.38, 0.24), 8.0, (0.32, 0.25, 0.18), "table", static=True, material=WOOD_MATERIAL)
    table_leg_fr = cuboid_rigid("sorting_table_leg_fr", (0.07, 0.07, 0.48), (2.64, -0.38, 0.24), 8.0, (0.32, 0.25, 0.18), "table", static=True, material=WOOD_MATERIAL)
    table_leg_bl = cuboid_rigid("sorting_table_leg_bl", (0.07, 0.07, 0.48), (0.96, 0.38, 0.24), 8.0, (0.32, 0.25, 0.18), "table", static=True, material=WOOD_MATERIAL)
    table_leg_br = cuboid_rigid("sorting_table_leg_br", (0.07, 0.07, 0.48), (2.64, 0.38, 0.24), 8.0, (0.32, 0.25, 0.18), "table", static=True, material=WOOD_MATERIAL)

    bin_recycle_bottom = cuboid_rigid("bin_recycle_bottom", (0.50, 0.50, 0.04), (3.0, -0.72, 0.02), 16.0, (0.04, 0.20, 0.72), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_recycle_left = cuboid_rigid("bin_recycle_left", (0.04, 0.50, 0.62), (2.77, -0.72, 0.33), 16.0, (0.04, 0.20, 0.72), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_recycle_right = cuboid_rigid("bin_recycle_right", (0.04, 0.50, 0.62), (3.23, -0.72, 0.33), 16.0, (0.04, 0.20, 0.72), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_recycle_front = cuboid_rigid("bin_recycle_front", (0.50, 0.04, 0.62), (3.0, -0.95, 0.33), 16.0, (0.04, 0.20, 0.72), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_recycle_back = cuboid_rigid("bin_recycle_back", (0.50, 0.04, 0.62), (3.0, -0.49, 0.33), 16.0, (0.04, 0.20, 0.72), "bin", static=True, material=BIN_PLASTIC_MATERIAL)

    bin_kitchen_bottom = cuboid_rigid("bin_kitchen_bottom", (0.50, 0.50, 0.04), (3.0, -0.24, 0.02), 16.0, (0.04, 0.48, 0.16), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_kitchen_left = cuboid_rigid("bin_kitchen_left", (0.04, 0.50, 0.62), (2.77, -0.24, 0.33), 16.0, (0.04, 0.48, 0.16), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_kitchen_right = cuboid_rigid("bin_kitchen_right", (0.04, 0.50, 0.62), (3.23, -0.24, 0.33), 16.0, (0.04, 0.48, 0.16), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_kitchen_front = cuboid_rigid("bin_kitchen_front", (0.50, 0.04, 0.62), (3.0, -0.47, 0.33), 16.0, (0.04, 0.48, 0.16), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_kitchen_back = cuboid_rigid("bin_kitchen_back", (0.50, 0.04, 0.62), (3.0, -0.01, 0.33), 16.0, (0.04, 0.48, 0.16), "bin", static=True, material=BIN_PLASTIC_MATERIAL)

    bin_hazard_bottom = cuboid_rigid("bin_hazard_bottom", (0.50, 0.50, 0.04), (3.0, 0.24, 0.02), 16.0, (0.72, 0.07, 0.06), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_hazard_left = cuboid_rigid("bin_hazard_left", (0.04, 0.50, 0.62), (2.77, 0.24, 0.33), 16.0, (0.72, 0.07, 0.06), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_hazard_right = cuboid_rigid("bin_hazard_right", (0.04, 0.50, 0.62), (3.23, 0.24, 0.33), 16.0, (0.72, 0.07, 0.06), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_hazard_front = cuboid_rigid("bin_hazard_front", (0.50, 0.04, 0.62), (3.0, 0.01, 0.33), 16.0, (0.72, 0.07, 0.06), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_hazard_back = cuboid_rigid("bin_hazard_back", (0.50, 0.04, 0.62), (3.0, 0.47, 0.33), 16.0, (0.72, 0.07, 0.06), "bin", static=True, material=BIN_PLASTIC_MATERIAL)

    bin_other_bottom = cuboid_rigid("bin_other_bottom", (0.50, 0.50, 0.04), (3.0, 0.72, 0.02), 16.0, (0.28, 0.28, 0.28), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_other_left = cuboid_rigid("bin_other_left", (0.04, 0.50, 0.62), (2.77, 0.72, 0.33), 16.0, (0.28, 0.28, 0.28), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_other_right = cuboid_rigid("bin_other_right", (0.04, 0.50, 0.62), (3.23, 0.72, 0.33), 16.0, (0.28, 0.28, 0.28), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_other_front = cuboid_rigid("bin_other_front", (0.50, 0.04, 0.62), (3.0, 0.49, 0.33), 16.0, (0.28, 0.28, 0.28), "bin", static=True, material=BIN_PLASTIC_MATERIAL)
    bin_other_back = cuboid_rigid("bin_other_back", (0.50, 0.04, 0.62), (3.0, 0.95, 0.33), 16.0, (0.28, 0.28, 0.28), "bin", static=True, material=BIN_PLASTIC_MATERIAL)

    trash_00 = usd_rigid("trash_cracker_box_0", f"{YCB_AXIS_ALIGNED_PHYSICS_DIR}/003_cracker_box.usd", ycb_table_pos_from_min_y(1.30, -0.31, "003_cracker_box"), uniform_scale(1.0), 0.08, PAPER_MATERIAL, "recyclable_paper", rot=ROT_X_90)
    trash_01 = usd_rigid("trash_sugar_box_0", f"{YCB_AXIS_ALIGNED_PHYSICS_DIR}/004_sugar_box.usd", ycb_table_pos_from_min_y(1.49, -0.19, "004_sugar_box"), uniform_scale(1.0), 0.10, PAPER_MATERIAL, "recyclable_paper", rot=ROT_X_90)
    trash_02 = usd_rigid("trash_tomato_soup_can_0", f"{YCB_AXIS_ALIGNED_PHYSICS_DIR}/005_tomato_soup_can.usd", ycb_table_pos_from_min_y(1.68, -0.33, "005_tomato_soup_can"), uniform_scale(1.0), 0.08, METAL_MATERIAL, "recyclable_metal", rot=ROT_X_90)
    trash_03 = usd_rigid("trash_mustard_bottle_0", f"{YCB_AXIS_ALIGNED_PHYSICS_DIR}/006_mustard_bottle.usd", ycb_table_pos_from_min_y(1.86, -0.20, "006_mustard_bottle"), uniform_scale(1.0), 0.08, PLASTIC_MATERIAL, "recyclable_plastic", rot=ROT_X_90)
    trash_04 = usd_rigid("trash_banana_0", f"{YCB_AXIS_ALIGNED_DIR}/011_banana.usd", ycb_table_pos_from_min_y(2.04, -0.32, "011_banana"), uniform_scale(1.0), 0.08, FOOD_SKIN_MATERIAL, "kitchen_food", rot=ROT_X_90, apply_runtime_physics=False)
    trash_05 = usd_rigid("trash_potted_meat_can_0", f"{YCB_AXIS_ALIGNED_DIR}/010_potted_meat_can.usd", ycb_table_pos_from_min_y(1.04, -0.16, "010_potted_meat_can"), uniform_scale(1.0), 0.09, METAL_MATERIAL, "kitchen_food_residue", rot=ROT_X_90, apply_runtime_physics=False)
    trash_06 = usd_rigid("trash_bleach_cleanser_0", f"{YCB_AXIS_ALIGNED_DIR}/021_bleach_cleanser.usd", ycb_table_pos_from_min_y(1.48, 0.26, "021_bleach_cleanser", scale=0.85), uniform_scale(0.85), 0.18, PLASTIC_MATERIAL, "hazard_chemical", rot=ROT_X_90, apply_runtime_physics=False)
    trash_07 = usd_rigid("trash_large_marker_0", f"{YCB_AXIS_ALIGNED_DIR}/040_large_marker.usd", ycb_table_pos_from_min_y(1.06, 0.06, "040_large_marker"), uniform_scale(1.0), 0.02, PLASTIC_MATERIAL, "hazard_marker", rot=ROT_X_90, apply_runtime_physics=False)
    trash_08 = usd_rigid("trash_foam_brick_0", f"{YCB_AXIS_ALIGNED_DIR}/061_foam_brick.usd", ycb_table_pos_from_min_y(1.10, 0.31, "061_foam_brick"), uniform_scale(1.0), 0.02, PLASTIC_MATERIAL, "other_waste", rot=ROT_X_90, apply_runtime_physics=False)
    trash_09 = usd_rigid("trash_mug_0", f"{YCB_AXIS_ALIGNED_DIR}/025_mug.usd", ycb_table_pos_from_min_y(1.76, 0.11, "025_mug"), uniform_scale(1.0), 0.12, METAL_MATERIAL, "other_waste", rot=ROT_X_90, apply_runtime_physics=False)

    head_rgbd = CameraCfg(
        prim_path="{ENV_REGEX_NS}/Kuavo62/head_camera_depth/head_rgbd",
        update_period=1.0 / 30.0,
        width=640,
        height=480,
        data_types=["rgb", "distance_to_image_plane"],
        spawn=sim_utils.PinholeCameraCfg(focal_length=10.0, focus_distance=1.2, horizontal_aperture=20.955),
        offset=CameraCfg.OffsetCfg(pos=(0.0, 0.0, 0.0), rot=(0.405309, -0.579417, 0.579417, -0.405309), convention="ros"),
        update_latest_camera_pose=True,
    )


def tensor_to_numpy(value: torch.Tensor) -> np.ndarray:
    return value.detach().cpu().numpy()


def sanitize_rgb(rgb: np.ndarray) -> np.ndarray:
    rgb = np.asarray(rgb)
    if rgb.ndim == 4:
        rgb = rgb[0]
    if rgb.shape[-1] > 3:
        rgb = rgb[..., :3]
    if rgb.dtype != np.uint8:
        rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    return np.ascontiguousarray(rgb)


def sanitize_depth(depth: np.ndarray) -> np.ndarray:
    depth = np.asarray(depth)
    if depth.ndim == 4:
        depth = depth[0]
    if depth.ndim == 3:
        depth = depth[..., 0]
    return depth.astype(np.float32)


def save_depth_images(depth_m: np.ndarray, out_dir: Path, prefix: str = "head_depth") -> None:
    finite = np.isfinite(depth_m) & (depth_m > 0.0)
    depth_mm = np.zeros(depth_m.shape, dtype=np.uint16)
    depth_mm[finite] = np.clip(depth_m[finite] * 1000.0, 0, 65535).astype(np.uint16)
    Image.fromarray(depth_mm, mode="I;16").save(out_dir / f"{prefix}_mm.png")
    np.save(out_dir / f"{prefix}_m.npy", depth_m)
    vis = np.zeros((*depth_m.shape, 3), dtype=np.uint8)
    if finite.any():
        lo, hi = np.percentile(depth_m[finite], [2.0, 98.0])
        if hi <= lo:
            hi = lo + 1e-3
        norm = np.clip((depth_m - lo) / (hi - lo), 0.0, 1.0)
        norm_u8 = (255.0 * (1.0 - norm)).astype(np.uint8)
        vis[..., 0] = norm_u8
        vis[..., 1] = np.clip(255 - np.abs(norm_u8.astype(np.int16) - 128) * 2, 0, 255).astype(np.uint8)
        vis[..., 2] = 255 - norm_u8
        vis[~finite] = 0
    Image.fromarray(vis).save(out_dir / f"{prefix}_vis.png")


def color_for_index(index: int) -> tuple[int, int, int]:
    palette = [(230, 57, 70), (29, 150, 65), (37, 99, 235), (245, 158, 11), (168, 85, 247), (20, 184, 166), (236, 72, 153), (132, 204, 22)]
    return palette[index % len(palette)]


def blend_mask(base: np.ndarray, mask: np.ndarray, color: tuple[int, int, int], alpha: float = 0.42) -> np.ndarray:
    out = base.copy().astype(np.float32)
    mask = mask.astype(bool)
    out[mask] = (1.0 - alpha) * out[mask] + alpha * np.asarray(color, dtype=np.float32)
    return np.clip(out, 0, 255).astype(np.uint8)


def resize_mask(mask: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    if mask.shape == shape:
        return mask.astype(bool)
    return np.array(Image.fromarray(mask.astype(np.uint8) * 255).resize((shape[1], shape[0]), Image.Resampling.NEAREST)) > 0


def crop_instance(rgb: np.ndarray, mask: np.ndarray, bbox: tuple[float, float, float, float], margin: int = 16) -> Image.Image:
    h, w = rgb.shape[:2]
    x0, y0, x1, y1 = bbox
    x0_i = max(0, int(math.floor(x0)) - margin)
    y0_i = max(0, int(math.floor(y0)) - margin)
    x1_i = min(w, int(math.ceil(x1)) + margin)
    y1_i = min(h, int(math.ceil(y1)) + margin)
    crop = rgb[y0_i:y1_i, x0_i:x1_i].copy()
    crop_mask = mask[y0_i:y1_i, x0_i:x1_i]
    if crop.size == 0:
        return Image.fromarray(rgb)
    background = np.full_like(crop, 32)
    masked = np.where(crop_mask[..., None], crop, background)
    return Image.fromarray(masked)


def get_yolo_model() -> Any:
    global _YOLO_MODEL
    if _YOLO_MODEL is None:
        from ultralytics import YOLO

        _YOLO_MODEL = YOLO(str((WORKSPACE_ROOT / args_cli.yolo_weights).resolve()))
    return _YOLO_MODEL


def run_yolo(rgb: np.ndarray, out_dir: Path) -> list[YoloInstance]:
    height, width = rgb.shape[:2]
    instances: list[YoloInstance] = []
    overlay = rgb.copy()
    union = np.zeros((height, width), dtype=bool)
    if args_cli.skip_yolo:
        Image.fromarray(overlay).save(out_dir / "yolo_overlay.png")
        Image.fromarray(union.astype(np.uint8) * 255).save(out_dir / "yolo_union_mask.png")
        (out_dir / "yolo_instances.json").write_text("[]")
        return instances

    result = get_yolo_model().predict(rgb, imgsz=args_cli.yolo_imgsz, conf=args_cli.yolo_conf, verbose=False)[0]
    masks = None if result.masks is None or result.masks.data is None else result.masks.data.detach().cpu().numpy()
    boxes = result.boxes
    pil = Image.fromarray(overlay)
    draw = ImageDraw.Draw(pil)
    if boxes is not None and len(boxes) > 0:
        for idx in range(len(boxes)):
            xyxy = tuple(float(x) for x in boxes.xyxy[idx].detach().cpu().numpy().tolist())
            cls_id = int(boxes.cls[idx].item())
            conf = float(boxes.conf[idx].item())
            label = str(result.names.get(cls_id, str(cls_id)))
            mask = np.zeros((height, width), dtype=bool)
            if masks is not None and idx < masks.shape[0]:
                mask = resize_mask(masks[idx] > 0.5, (height, width))
                union |= mask
                overlay = blend_mask(np.array(pil), mask, color_for_index(idx))
                pil = Image.fromarray(overlay)
                draw = ImageDraw.Draw(pil)
            color = color_for_index(idx)
            draw.rectangle(xyxy, outline=color, width=3)
            draw.text((xyxy[0] + 3, max(0.0, xyxy[1] - 14)), f"{idx}:{label} {conf:.2f}", fill=color)
            if mask.any():
                instances.append(YoloInstance(idx, label, conf, xyxy, mask))
    instances.sort(key=lambda item: (item.yolo_confidence, int(item.mask.sum())), reverse=True)
    Image.fromarray(np.array(pil)).save(out_dir / "yolo_overlay.png")
    Image.fromarray(union.astype(np.uint8) * 255).save(out_dir / "yolo_union_mask.png")
    (out_dir / "yolo_instances.json").write_text(
        json.dumps(
            [
                {
                    "index": inst.index,
                    "yolo_label_weak": inst.yolo_label,
                    "yolo_confidence": inst.yolo_confidence,
                    "bbox_xyxy": inst.bbox_xyxy,
                    "mask_pixels": int(inst.mask.sum()),
                }
                for inst in instances
            ],
            ensure_ascii=False,
            indent=2,
        )
    )
    return instances[: args_cli.max_vlm_instances]


def get_vlm_classifier() -> GlmVlmClassifier:
    global _VLM_CLASSIFIER
    if _VLM_CLASSIFIER is None:
        _VLM_CLASSIFIER = GlmVlmClassifier(model=args_cli.vlm_model, endpoint=args_cli.vlm_endpoint)
    return _VLM_CLASSIFIER


def classify_instances(rgb: np.ndarray, instances: list[YoloInstance], out_dir: Path) -> None:
    pil = Image.fromarray(rgb.copy())
    draw = ImageDraw.Draw(pil)
    for rank, inst in enumerate(instances):
        crop = crop_instance(rgb, inst.mask, inst.bbox_xyxy)
        crop.save(out_dir / f"vlm_crop_{rank:02d}_yolo_{inst.index:02d}.jpg")
        if args_cli.skip_vlm:
            if inst.vlm is None:
                inst.vlm = VlmClassification(inst.yolo_label, "其他垃圾", inst.yolo_confidence, "Debug fallback from YOLO weak label.")
        else:
            inst.vlm = get_vlm_classifier().classify_crop(crop, yolo_label=inst.yolo_label, yolo_confidence=inst.yolo_confidence)
        color = color_for_index(rank)
        x0, y0, x1, y1 = inst.bbox_xyxy
        label = inst.vlm.object_name if inst.vlm else "unknown"
        category = inst.vlm.waste_category if inst.vlm else ""
        conf = inst.vlm.confidence if inst.vlm else 0.0
        if inst.vlm and inst.vlm.error:
            label = "VLM_ERROR"
        draw.rectangle(inst.bbox_xyxy, outline=color, width=3)
        draw.text((x0 + 3, min(max(0.0, y0 + 4), rgb.shape[0] - 20)), f"{rank}:{label}/{category} {conf:.2f}", fill=color)
    pil.save(out_dir / "vlm_overlay.png")
    (out_dir / "vlm_results.json").write_text(
        json.dumps(
            [
                {
                    "rank": rank,
                    "yolo_index": inst.index,
                    "yolo_label_weak": inst.yolo_label,
                    "yolo_confidence": inst.yolo_confidence,
                    "bbox_xyxy": inst.bbox_xyxy,
                    "mask_pixels": int(inst.mask.sum()),
                    "source": inst.source,
                    "scene_key": inst.scene_key,
                    "scene_object_name": inst.scene_object_name,
                    "center_3d": inst.center_3d.tolist() if inst.center_3d is not None else None,
                    "object_name": inst.vlm.object_name if inst.vlm else "unknown",
                    "waste_category": inst.vlm.waste_category if inst.vlm else "",
                    "vlm_confidence": inst.vlm.confidence if inst.vlm else 0.0,
                    "vlm_reason": inst.vlm.reason if inst.vlm else "",
                    "vlm_error": inst.vlm.error if inst.vlm else "not_run",
                }
                for rank, inst in enumerate(instances)
            ],
            ensure_ascii=False,
            indent=2,
        )
    )


def choose_target(instances: list[YoloInstance]) -> tuple[YoloInstance | None, str]:
    candidates = []
    for inst in instances:
        mask_pixels = int(inst.mask.sum())
        image_pixels = int(inst.mask.shape[0] * inst.mask.shape[1])
        x0, y0, x1, y1 = inst.bbox_xyxy
        bbox_area_fraction = max(0.0, (x1 - x0) * (y1 - y0)) / max(1, image_pixels)
        mask_area_fraction = mask_pixels / max(1, image_pixels)
        edge_margin = 4.0
        touches_edge = x0 <= edge_margin or y0 <= edge_margin or x1 >= inst.mask.shape[1] - edge_margin or y1 >= inst.mask.shape[0] - edge_margin
        if touches_edge and inst.center_3d is None:
            continue
        if mask_pixels < MIN_TARGET_MASK_PIXELS:
            continue
        if mask_area_fraction > MAX_TARGET_MASK_FRACTION or bbox_area_fraction > MAX_TARGET_BBOX_AREA_FRACTION:
            continue
        if inst.vlm is None:
            continue
        if inst.vlm.error:
            continue
        if not args_cli.skip_vlm and inst.vlm.confidence < args_cli.vlm_min_conf:
            continue
        if args_cli.target_category and inst.vlm.waste_category != args_cli.target_category:
            continue
        if args_cli.target_object_name and args_cli.target_object_name not in inst.vlm.object_name:
            continue
        priority = TARGET_PRIORITY.get(inst.vlm.waste_category, 99)
        reach_penalty, reach_cost = reachability_score(inst.center_3d)
        source_penalty = 0 if inst.source == "depth_component" and args_cli.use_centroid_fallback else 1
        grasp_priority = SCENE_GRASP_PRIORITY.get(inst.scene_key or "", 20)
        candidates.append((reach_penalty, source_penalty, priority, grasp_priority, reach_cost, -inst.vlm.confidence, -mask_pixels, inst))
    if not candidates:
        return None, "No VLM-labeled YOLO instance satisfied the target filters."
    candidates.sort(key=lambda item: (item[0], item[1], item[2], item[3], item[4]))
    reason = "auto_priority_reachable" if candidates[0][0] == 0 else "auto_priority_no_reachable_target"
    if candidates[0][7].source == "depth_component":
        reason += "_depth_component"
    return candidates[0][7], reason


def get_graspnet_wrapper() -> GraspNetWrapper:
    global _GRASPNET_WRAPPER
    if _GRASPNET_WRAPPER is None:
        _GRASPNET_WRAPPER = GraspNetWrapper(
            WORKSPACE_ROOT / args_cli.graspnet_repo,
            WORKSPACE_ROOT / args_cli.graspnet_checkpoint,
            num_point=args_cli.graspnet_num_point,
            collision_thresh=0.01,
            voxel_size=0.01,
        )
    return _GRASPNET_WRAPPER


def camera_to_world_matrix(camera: CameraCfg) -> np.ndarray:
    data = camera.data
    pos_w = tensor_to_numpy(data.pos_w)[0].astype(np.float32)
    quat_w_ros = data.quat_w_ros
    rot_w = tensor_to_numpy(matrix_from_quat(quat_w_ros))[0].astype(np.float32)
    t_camera_to_world = np.eye(4, dtype=np.float32)
    t_camera_to_world[:3, :3] = rot_w
    t_camera_to_world[:3, 3] = pos_w
    return t_camera_to_world


def capture_head_camera(scene: InteractiveScene) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    camera = scene["head_rgbd"]
    rgb = sanitize_rgb(tensor_to_numpy(camera.data.output["rgb"])[0])
    depth = sanitize_depth(tensor_to_numpy(camera.data.output["distance_to_image_plane"])[0])
    intrinsics = tensor_to_numpy(camera.data.intrinsic_matrices)[0].astype(np.float32)
    t_camera_to_world = camera_to_world_matrix(camera)
    return rgb, depth, intrinsics, t_camera_to_world


def mask_points_world(
    mask: np.ndarray,
    depth_m: np.ndarray,
    intrinsics: np.ndarray,
    t_camera_to_world: np.ndarray,
    *,
    min_z: float = TABLE_SURFACE_Z + 0.006,
    max_z: float = TABLE_SURFACE_Z + 0.45,
) -> np.ndarray:
    ys, xs = np.nonzero(mask.astype(bool))
    if len(xs) == 0:
        return np.zeros((0, 3), dtype=np.float32)
    depths = depth_m[ys, xs]
    valid = np.isfinite(depths) & (depths > 0.05) & (depths < 5.0)
    if not np.any(valid):
        return np.zeros((0, 3), dtype=np.float32)
    xs = xs[valid].astype(np.float32)
    ys = ys[valid].astype(np.float32)
    depths = depths[valid].astype(np.float32)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    if fx == 0.0 or fy == 0.0:
        return np.zeros((0, 3), dtype=np.float32)
    points_camera = np.stack(((xs - cx) * depths / fx, (ys - cy) * depths / fy, depths), axis=1)
    points_h = np.concatenate([points_camera, np.ones((points_camera.shape[0], 1), dtype=np.float32)], axis=1)
    points_world = (t_camera_to_world @ points_h.T).T[:, :3].astype(np.float32)
    object_like = (points_world[:, 2] > min_z) & (points_world[:, 2] < max_z)
    if np.count_nonzero(object_like) < 25:
        return np.zeros((0, 3), dtype=np.float32)
    return points_world[object_like]


def depth_image_to_world_map(depth_m: np.ndarray, intrinsics: np.ndarray, t_camera_to_world: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    height, width = depth_m.shape
    ys, xs = np.indices((height, width), dtype=np.float32)
    depths = depth_m.astype(np.float32)
    valid = np.isfinite(depths) & (depths > 0.05) & (depths < 5.0)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    points_world = np.zeros((height, width, 3), dtype=np.float32)
    if fx == 0.0 or fy == 0.0 or not np.any(valid):
        return points_world, np.zeros((height, width), dtype=bool)
    x_cam = (xs[valid] - cx) * depths[valid] / fx
    y_cam = (ys[valid] - cy) * depths[valid] / fy
    z_cam = depths[valid]
    points_camera = np.stack((x_cam, y_cam, z_cam), axis=1)
    points_h = np.concatenate([points_camera, np.ones((points_camera.shape[0], 1), dtype=np.float32)], axis=1)
    points_world[valid] = (t_camera_to_world @ points_h.T).T[:, :3].astype(np.float32)
    return points_world, valid


def draw_depth_component_overlay(rgb: np.ndarray, components: list[dict[str, Any]], out_dir: Path) -> None:
    pil = Image.fromarray(rgb.copy())
    draw = ImageDraw.Draw(pil)
    for rank, item in enumerate(components):
        color = color_for_index(rank + 3)
        x0, y0, x1, y1 = item["bbox_xyxy"]
        draw.rectangle((x0, y0, x1, y1), outline=color, width=3)
        draw.text((x0 + 3, min(max(0.0, y0 + 4), rgb.shape[0] - 20)), f"D{rank}:{item['scene_object_name']} {item['category']}", fill=color)
    pil.save(out_dir / "depth_component_overlay.png")


def detect_tabletop_depth_components(
    scene: InteractiveScene,
    rgb: np.ndarray,
    depth_m: np.ndarray,
    intrinsics: np.ndarray,
    t_camera_to_world: np.ndarray,
    out_dir: Path,
) -> list[YoloInstance]:
    instances: list[YoloInstance] = []
    metadata: list[dict[str, Any]] = []
    if args_cli.disable_depth_component_fallback:
        draw_depth_component_overlay(rgb, metadata, out_dir)
        (out_dir / "depth_components.json").write_text("[]\n")
        return instances
    try:
        import cv2  # type: ignore
    except Exception as exc:
        draw_depth_component_overlay(rgb, metadata, out_dir)
        (out_dir / "depth_components.json").write_text(json.dumps({"error": f"OpenCV unavailable: {exc!r}"}, ensure_ascii=False, indent=2))
        return instances

    points_world, valid = depth_image_to_world_map(depth_m, intrinsics, t_camera_to_world)
    candidate = (
        valid
        & (points_world[:, :, 2] > TABLE_SURFACE_Z + 0.006)
        & (points_world[:, :, 2] < TABLE_SURFACE_Z + 0.36)
        & (points_world[:, :, 0] > TABLE_X_LIMITS[0])
        & (points_world[:, :, 0] < TABLE_X_LIMITS[1])
        & (points_world[:, :, 1] > TABLE_Y_LIMITS[0])
        & (points_world[:, :, 1] < TABLE_Y_LIMITS[1])
    )
    mask_u8 = candidate.astype(np.uint8) * 255
    kernel = np.ones((3, 3), dtype=np.uint8)
    mask_u8 = cv2.morphologyEx(mask_u8, cv2.MORPH_OPEN, kernel)
    mask_u8 = cv2.morphologyEx(mask_u8, cv2.MORPH_CLOSE, kernel)
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask_u8, connectivity=8)
    height, width = depth_m.shape
    for label_id in range(1, num_labels):
        x, y, w, h, area = (int(v) for v in stats[label_id])
        if area < 80 or area > 24000:
            continue
        if x <= 2 or y <= 2 or x + w >= width - 2 or y + h >= height - 2:
            continue
        component_mask = labels == label_id
        points = points_world[component_mask]
        points = points[np.isfinite(points).all(axis=1)]
        if points.shape[0] < 50:
            continue
        center = np.median(points, axis=0).astype(np.float32)
        xy_extent = np.percentile(points[:, :2], 95, axis=0) - np.percentile(points[:, :2], 5, axis=0)
        z_extent = float(np.percentile(points[:, 2], 95) - np.percentile(points[:, 2], 5))
        if float(np.max(xy_extent)) > 0.30 or z_extent > 0.34:
            continue
        scene_key, scene_object_name, match_distance = locate_target_rigid_object(scene, center)
        if match_distance > 0.24:
            scene_key = None
            scene_object_name = "tabletop_object"
        category = category_for_scene_key(scene_key)
        reach_penalty, reach_cost = reachability_score(center)
        grasp_priority = SCENE_GRASP_PRIORITY.get(scene_key or "", 20)
        score = 1.0 / (1.0 + grasp_priority + 2.0 * reach_penalty + reach_cost + float(np.max(xy_extent)))
        vlm = VlmClassification(
            scene_object_name or "tabletop_object",
            category,
            0.55,
            "Head-depth tabletop component fallback matched to nearest YCB rigid object.",
        )
        inst = YoloInstance(
            1000 + len(instances),
            f"depth_{scene_object_name or 'object'}",
            float(score),
            (float(x), float(y), float(x + w), float(y + h)),
            component_mask,
            vlm=vlm,
            center_3d=center,
            source="depth_component",
            scene_key=scene_key,
            scene_object_name=scene_object_name,
            component_score=float(score),
        )
        instances.append(inst)
        metadata.append(
            {
                "index": inst.index,
                "bbox_xyxy": inst.bbox_xyxy,
                "mask_pixels": int(component_mask.sum()),
                "center_3d": center.tolist(),
                "xy_extent_m": xy_extent.astype(float).tolist(),
                "z_extent_m": z_extent,
                "scene_key": scene_key,
                "scene_object_name": scene_object_name,
                "category": category,
                "match_distance_m": float(match_distance),
                "reach_penalty": int(reach_penalty),
                "reach_cost": float(reach_cost),
                "score": float(score),
            }
        )
    if len(instances) > 0:
        instances.sort(
            key=lambda inst: (
                reachability_score(inst.center_3d)[0],
                SCENE_GRASP_PRIORITY.get(inst.scene_key or "", 20),
                reachability_score(inst.center_3d)[1],
                -inst.component_score,
            )
        )
        instances = instances[:6]
        ordered_indices = {inst.index for inst in instances}
        metadata = [item for item in metadata if item["index"] in ordered_indices]
    draw_depth_component_overlay(rgb, metadata, out_dir)
    (out_dir / "depth_components.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2))
    return instances


def perceived_from_target(target: YoloInstance, center_3d: np.ndarray | None) -> PerceivedObject:
    return PerceivedObject(
        object_id=target.index,
        object_name=target.vlm.object_name if target.vlm else "unknown",
        class_name=target.vlm.object_name if target.vlm else target.yolo_label,
        confidence=target.vlm.confidence if target.vlm else target.yolo_confidence,
        bbox_xyxy=target.bbox_xyxy,
        mask=target.mask,
        center_2d=(0.5 * (target.bbox_xyxy[0] + target.bbox_xyxy[2]), 0.5 * (target.bbox_xyxy[1] + target.bbox_xyxy[3])),
        center_3d=center_3d,
        waste_category=target.vlm.waste_category if target.vlm else "",
    )


def centroid_fallback_grasp(
    target: YoloInstance,
    depth_m: np.ndarray,
    intrinsics: np.ndarray,
    t_camera_to_world: np.ndarray,
) -> tuple[SelectedGrasp | None, dict[str, Any]]:
    points_world = mask_points_world(target.mask, depth_m, intrinsics, t_camera_to_world)
    if points_world.shape[0] < 25:
        return None, {"source": "fallback", "error": f"Only {points_world.shape[0]} valid mask point-cloud samples."}
    center = np.median(points_world, axis=0).astype(np.float32)
    target.center_3d = center
    xy_extent = np.percentile(points_world[:, :2], 95, axis=0) - np.percentile(points_world[:, :2], 5, axis=0)
    width = clamp_width(float(max(0.020, min(float(np.min(xy_extent)) + 0.012, 0.068))))
    pose = np.eye(4, dtype=np.float32)
    pose[:3, :3] = np.array(
        [
            [1.0, 0.0, 0.0],
            [0.0, -1.0, 0.0],
            [0.0, 0.0, -1.0],
        ],
        dtype=np.float32,
    )
    pose[:3, 3] = center
    pose[2, 3] = max(float(center[2]), TABLE_SURFACE_Z + 0.035)
    selected = SelectedGrasp(
        pose_world=pose,
        width=width,
        score=0.25,
        center_2d=(0.5 * (target.bbox_xyxy[0] + target.bbox_xyxy[2]), 0.5 * (target.bbox_xyxy[1] + target.bbox_xyxy[3])),
        target=perceived_from_target(target, center),
    )
    return selected, {
        "source": "fallback",
        "point_count": int(points_world.shape[0]),
        "center_world": center.tolist(),
        "estimated_width_m": width,
    }


def draw_selected_grasp_overlay(rgb: np.ndarray, selected: SelectedGrasp | None, out_dir: Path, *, label: str) -> None:
    pil = Image.fromarray(rgb.copy())
    draw = ImageDraw.Draw(pil)
    if selected is not None:
        u, v = selected.center_2d
        draw.ellipse((u - 14, v - 14, u + 14, v + 14), outline=(255, 0, 0), width=5)
        draw.text((u + 16, v + 8), f"{label} {selected.score:.2f}", fill=(255, 0, 0))
    pil.save(out_dir / "selected_grasp_overlay.png")


def run_graspnet_for_target(
    rgb: np.ndarray,
    depth_m: np.ndarray,
    intrinsics: np.ndarray,
    t_camera_to_world: np.ndarray,
    target: YoloInstance | None,
    out_dir: Path,
) -> tuple[SelectedGrasp | None, dict[str, Any]]:
    metadata: dict[str, Any] = {
        "enabled": not args_cli.skip_graspnet,
        "candidate_count": 0,
        "filtered_count": 0,
        "selected": None,
        "source": "",
        "fallback": None,
        "error": "",
    }
    blank = np.zeros(depth_m.shape, dtype=np.uint8)
    if target is None:
        Image.fromarray(blank).save(out_dir / "target_mask.png")
        Image.fromarray(blank).save(out_dir / "graspnet_workspace_mask.png")
        Image.fromarray(rgb).save(out_dir / "graspnet_overlay.png")
        Image.fromarray(rgb).save(out_dir / "selected_grasp_overlay.png")
        metadata["error"] = "No target selected."
        return None, metadata
    Image.fromarray(target.mask.astype(np.uint8) * 255).save(out_dir / "target_mask.png")
    Image.fromarray(target.mask.astype(np.uint8) * 255).save(out_dir / "graspnet_workspace_mask.png")
    points_world = mask_points_world(target.mask, depth_m, intrinsics, t_camera_to_world)
    target.center_3d = np.median(points_world, axis=0).astype(np.float32) if points_world.shape[0] else masked_depth_center_world(target.mask, depth_m, intrinsics, t_camera_to_world)
    perceived = perceived_from_target(target, target.center_3d)
    if args_cli.skip_graspnet:
        Image.fromarray(rgb).save(out_dir / "graspnet_overlay.png")
        selected = None
        if args_cli.use_centroid_fallback:
            selected, fallback_meta = centroid_fallback_grasp(target, depth_m, intrinsics, t_camera_to_world)
            metadata["fallback"] = fallback_meta
            metadata["source"] = "fallback" if selected is not None else ""
        draw_selected_grasp_overlay(rgb, selected, out_dir, label="fallback")
        if selected is not None:
            metadata["selected"] = {
                "source": "fallback",
                "score": selected.score,
                "width_m": selected.width,
                "center_2d": selected.center_2d,
                "pose_world": selected.pose_world.tolist(),
            }
        elif args_cli.use_centroid_fallback:
            metadata["error"] = metadata["fallback"].get("error", "Centroid fallback failed.") if metadata["fallback"] else "Centroid fallback failed."
        return selected, metadata
    try:
        wrapper = get_graspnet_wrapper()
        candidates = wrapper.detect(rgb, depth_m, intrinsics, target.mask)
        metadata["candidate_count"] = int(len(candidates.scores))
        filtered = filter_grasps_by_mask(candidates, target.mask, margin=5)
        metadata["filtered_count"] = int(len(filtered.scores))
        selected = select_best_grasp(filtered, perceived, t_camera_to_world=t_camera_to_world, table_surface_z=TABLE_SURFACE_Z)
        source = "graspnet"
        if selected is None and args_cli.use_centroid_fallback:
            selected, fallback_meta = centroid_fallback_grasp(target, depth_m, intrinsics, t_camera_to_world)
            metadata["fallback"] = fallback_meta
            source = "fallback" if selected is not None else ""
        draw_grasp_overlays(rgb, candidates, selected, out_dir)
        if selected is not None:
            metadata["source"] = source
            metadata["selected"] = {
                "source": source,
                "score": selected.score,
                "width_m": selected.width,
                "center_2d": selected.center_2d,
                "pose_world": selected.pose_world.tolist(),
            }
        else:
            metadata["error"] = "No physically valid grasp remained after filtering."
        return selected, metadata
    except Exception as exc:
        metadata["error"] = repr(exc)
        pil = Image.fromarray(rgb.copy())
        ImageDraw.Draw(pil).text((12, 12), f"GraspNet error: {exc!r}", fill=(255, 0, 0))
        pil.save(out_dir / "graspnet_overlay.png")
        selected = None
        if args_cli.use_centroid_fallback:
            selected, fallback_meta = centroid_fallback_grasp(target, depth_m, intrinsics, t_camera_to_world)
            metadata["fallback"] = fallback_meta
            if selected is not None:
                metadata["source"] = "fallback"
                metadata["selected"] = {
                    "source": "fallback",
                    "score": selected.score,
                    "width_m": selected.width,
                    "center_2d": selected.center_2d,
                    "pose_world": selected.pose_world.tolist(),
                }
        draw_selected_grasp_overlay(rgb, selected, out_dir, label="fallback" if selected is not None else "none")
        return selected, metadata


def draw_grasp_overlays(rgb: np.ndarray, candidates: GraspCandidates, selected: SelectedGrasp | None, out_dir: Path) -> None:
    pil = Image.fromarray(rgb.copy())
    draw = ImageDraw.Draw(pil)
    order = np.argsort(candidates.scores)[::-1][: min(args_cli.graspnet_max_draw, len(candidates.scores))]
    for rank, idx in enumerate(order):
        u, v = candidates.centers_2d[idx]
        if not (np.isfinite(u) and np.isfinite(v)):
            continue
        u_f = float(u)
        v_f = float(v)
        color = color_for_index(rank)
        r = 5 if rank else 9
        draw.ellipse((u_f - r, v_f - r, u_f + r, v_f + r), outline=color, width=3)
        draw.text((u_f + 7, v_f + 4), f"{rank}:{float(candidates.scores[idx]):.2f}", fill=color)
    pil.save(out_dir / "graspnet_overlay.png")
    selected_pil = pil.copy()
    selected_draw = ImageDraw.Draw(selected_pil)
    if selected is not None:
        u, v = selected.center_2d
        selected_draw.ellipse((u - 14, v - 14, u + 14, v + 14), outline=(255, 0, 0), width=5)
        selected_draw.text((u + 16, v + 8), f"selected {selected.score:.2f}", fill=(255, 0, 0))
    selected_pil.save(out_dir / "selected_grasp_overlay.png")


def reset_scene(scene: InteractiveScene) -> None:
    robot: Articulation = scene["robot"]
    root_state = robot.data.default_root_state.clone()
    root_state[:, :3] += scene.env_origins
    root_state[:, 7:] = 0.0
    robot.write_root_pose_to_sim(root_state[:, :7])
    robot.write_root_velocity_to_sim(root_state[:, 7:])
    robot.write_joint_state_to_sim(robot.data.default_joint_pos.clone(), torch.zeros_like(robot.data.default_joint_vel))
    robot.set_joint_position_target(robot.data.default_joint_pos.clone())
    scene.reset()


def stabilize_robot_base(robot: Articulation, locked_root_pose_w: torch.Tensor | None = None) -> None:
    root_state = robot.data.root_state_w.clone()
    for env_id in range(root_state.shape[0]):
        if locked_root_pose_w is not None:
            root_state[env_id, 0:2] = locked_root_pose_w[env_id, 0:2]
            yaw = yaw_from_quat_wxyz(locked_root_pose_w[env_id, 3:7])
        else:
            yaw = yaw_from_quat_wxyz(root_state[env_id, 3:7])
        root_state[env_id, 2] = ROBOT_STABILIZED_BASE_Z
        root_state[env_id, 3:7] = torch.tensor(quat_wxyz_from_yaw(yaw), device=robot.device)
        root_state[env_id, 7:] = 0.0
    robot.write_root_pose_to_sim(root_state[:, :7])
    robot.write_root_velocity_to_sim(root_state[:, 7:])


def stabilize_robot_base_for_nav(robot: Articulation) -> None:
    root_state = robot.data.root_state_w.clone()
    for env_id in range(root_state.shape[0]):
        yaw = yaw_from_quat_wxyz(root_state[env_id, 3:7])
        root_state[env_id, 2] = ROBOT_STABILIZED_BASE_Z
        root_state[env_id, 3:7] = torch.tensor(quat_wxyz_from_yaw(yaw), device=robot.device)
        root_state[env_id, 9] = 0.0
        root_state[env_id, 10] = 0.0
        root_state[env_id, 11] = 0.0
    robot.write_root_pose_to_sim(root_state[:, :7])
    robot.write_root_velocity_to_sim(root_state[:, 7:])


def min_jerk(alpha: float) -> float:
    alpha = max(0.0, min(1.0, alpha))
    return 10.0 * alpha**3 - 15.0 * alpha**4 + 6.0 * alpha**5


def clamp_joint_step(desired: torch.Tensor, previous: torch.Tensor, max_step: float) -> torch.Tensor:
    return previous + torch.clamp(desired - previous, min=-max_step, max=max_step)


def interpolate_quat_shortest_path(q0: torch.Tensor, q1: torch.Tensor, alpha: float) -> torch.Tensor:
    q1 = torch.where(torch.sum(q0 * q1, dim=1, keepdim=True) < 0.0, -q1, q1)
    q = (1.0 - alpha) * q0 + alpha * q1
    return torch.nn.functional.normalize(q, dim=1)


def pose_to_torch_command(target_pose_w: np.ndarray, robot: Articulation) -> tuple[torch.Tensor, torch.Tensor]:
    target_pos_w = torch.tensor(target_pose_w[:3, 3], dtype=torch.float32, device=robot.device).repeat(robot.num_instances, 1)
    target_rot_w = torch.tensor(target_pose_w[:3, :3], dtype=torch.float32, device=robot.device).repeat(robot.num_instances, 1, 1)
    target_quat_w = quat_from_matrix(target_rot_w)
    root_pose_w = robot.data.root_pose_w
    return subtract_frame_transforms(root_pose_w[:, 0:3], root_pose_w[:, 3:7], target_pos_w, target_quat_w)


def tcp_pose_to_wrist_pose(tcp_pose_w: np.ndarray, wrist_rot_w: np.ndarray | None = None) -> np.ndarray:
    wrist_pose_w = np.array(tcp_pose_w, dtype=np.float32).copy()
    if wrist_rot_w is not None:
        wrist_pose_w[:3, :3] = np.asarray(wrist_rot_w, dtype=np.float32)
    wrist_pose_w[:3, 3] = wrist_pose_w[:3, 3] - wrist_pose_w[:3, :3] @ GRIPPER_TCP_OFFSET_M
    return wrist_pose_w


def run_ik_segment(
    sim: SimulationContext,
    scene: InteractiveScene,
    robot: Articulation,
    ik_controller: DifferentialIKController,
    robot_entity_cfg: SceneEntityCfg,
    ee_body_id: int,
    ee_jacobi_idx: int,
    target_pose_w: np.ndarray,
    steps: int,
    *,
    gripper: AttachedParallelGripper | None = None,
    gripper_width: float | None = None,
    locked_root_pose_w: torch.Tensor | None = None,
) -> dict[str, float]:
    sim_dt = sim.get_physics_dt()
    target_pos_b, target_quat_b = pose_to_torch_command(target_pose_w, robot)
    ee_pose_w = robot.data.body_pose_w[:, ee_body_id]
    start_pos_b, start_quat_b = subtract_frame_transforms(
        robot.data.root_pose_w[:, 0:3], robot.data.root_pose_w[:, 3:7], ee_pose_w[:, 0:3], ee_pose_w[:, 3:7]
    )
    previous_joint_target = robot.data.joint_pos[:, robot_entity_cfg.joint_ids].clone()
    locked_joint_target = robot.data.default_joint_pos.clone()
    max_joint_step = 0.0
    final_pos_error = float("nan")
    final_pos_b = start_pos_b.clone()
    ik_controller.reset()
    command = torch.zeros(robot.num_instances, ik_controller.action_dim, device=robot.device)
    for step in range(max(1, steps)):
        alpha = min_jerk(step / max(1, steps - 1))
        desired_pos_b = (1.0 - alpha) * start_pos_b + alpha * target_pos_b
        desired_quat_b = interpolate_quat_shortest_path(start_quat_b, target_quat_b, alpha)
        jacobian = robot.root_physx_view.get_jacobians()[:, ee_jacobi_idx, :, robot_entity_cfg.joint_ids]
        ee_pose_w = robot.data.body_pose_w[:, ee_body_id]
        ee_pos_b, ee_quat_b = subtract_frame_transforms(
            robot.data.root_pose_w[:, 0:3], robot.data.root_pose_w[:, 3:7], ee_pose_w[:, 0:3], ee_pose_w[:, 3:7]
        )
        command[:, 0:3] = desired_pos_b
        if ik_controller.action_dim == 3:
            ik_controller.set_command(command, ee_quat=ee_quat_b)
        else:
            command[:, 3:7] = desired_quat_b
            ik_controller.set_command(command)
        joint_pos_des = ik_controller.compute(ee_pos_b, ee_quat_b, jacobian, robot.data.joint_pos[:, robot_entity_cfg.joint_ids])
        joint_pos_des = clamp_joint_step(joint_pos_des, previous_joint_target, args_cli.max_joint_step)
        max_joint_step = max(max_joint_step, float(torch.max(torch.abs(joint_pos_des - previous_joint_target)).item()))
        previous_joint_target = joint_pos_des.clone()

        robot.set_joint_position_target(locked_joint_target)
        robot.set_joint_position_target(joint_pos_des, joint_ids=robot_entity_cfg.joint_ids)
        if gripper is not None and gripper_width is not None:
            gripper.set_width(gripper_width)
        stabilize_robot_base(robot, locked_root_pose_w)
        scene.write_data_to_sim()
        sim.step(render=True)
        scene.update(sim_dt)
        ee_pose_w = robot.data.body_pose_w[:, ee_body_id]
        final_pos_b, _ = subtract_frame_transforms(
            robot.data.root_pose_w[:, 0:3], robot.data.root_pose_w[:, 3:7], ee_pose_w[:, 0:3], ee_pose_w[:, 3:7]
        )
        final_pos_error = float(torch.linalg.norm(target_pos_b - final_pos_b, dim=1).max().item())
    return {
        "max_joint_step_rad": max_joint_step,
        "final_pos_error_m": final_pos_error,
        "start_pos_b": start_pos_b[0].detach().cpu().tolist(),
        "target_pos_b": target_pos_b[0].detach().cpu().tolist(),
        "final_pos_b": final_pos_b[0].detach().cpu().tolist(),
    }


def trash_root_positions(scene: InteractiveScene) -> dict[str, np.ndarray]:
    positions: dict[str, np.ndarray] = {}
    for scene_key, object_name in TRASH_SCENE_OBJECTS:
        if scene_key not in scene.keys():
            continue
        positions[object_name] = tensor_to_numpy(scene[scene_key].data.root_state_w[0, :3]).astype(np.float32)
    return positions


def locate_target_rigid_object(scene: InteractiveScene, target_center_w: np.ndarray | None) -> tuple[str | None, str | None, float]:
    positions = trash_root_positions(scene)
    if not positions:
        return None, None, float("inf")
    if target_center_w is None:
        best_name, best_pos = min(positions.items(), key=lambda item: abs(float(item[1][2]) - TABLE_SURFACE_Z))
        scene_key = next((key for key, name in TRASH_SCENE_OBJECTS if name == best_name), None)
        return scene_key, best_name, float(abs(best_pos[2] - TABLE_SURFACE_Z))
    center = np.asarray(target_center_w, dtype=np.float32)
    best_name, best_pos = min(positions.items(), key=lambda item: float(np.linalg.norm(item[1][:2] - center[:2])))
    scene_key = next((key for key, name in TRASH_SCENE_OBJECTS if name == best_name), None)
    return scene_key, best_name, float(np.linalg.norm(best_pos[:2] - center[:2]))


def object_root_z(scene: InteractiveScene, scene_key: str | None) -> float | None:
    if scene_key is None or scene_key not in scene.keys():
        return None
    return float(scene[scene_key].data.root_state_w[0, 2].detach().cpu())


def lifted_object_delta(scene: InteractiveScene, initial_z_by_key: dict[str, float]) -> tuple[str | None, float]:
    best_key = None
    best_delta = -float("inf")
    for scene_key, _ in TRASH_SCENE_OBJECTS:
        if scene_key not in scene.keys() or scene_key not in initial_z_by_key:
            continue
        current_z = float(scene[scene_key].data.root_state_w[0, 2].detach().cpu())
        delta = current_z - initial_z_by_key[scene_key]
        if delta > best_delta:
            best_key = scene_key
            best_delta = delta
    return best_key, best_delta


def non_wheel_joint_ids(robot: Articulation, wheel_ids: list[int]) -> list[int]:
    wheel_id_set = {int(item) for item in wheel_ids}
    return [idx for idx in range(robot.num_joints) if idx not in wheel_id_set]


def hold_non_wheel_joints(robot: Articulation, locked_joint_target: torch.Tensor, wheel_ids: list[int]) -> None:
    joint_ids = non_wheel_joint_ids(robot, wheel_ids)
    if joint_ids:
        robot.set_joint_position_target(locked_joint_target[:, joint_ids], joint_ids=joint_ids)


def apply_wheel_velocity(robot: Articulation, wheel_ids: list[int], vx: float, wz: float) -> None:
    if len(wheel_ids) != 4:
        return
    left = (float(vx) - 0.5 * args_cli.track_width * float(wz)) / args_cli.wheel_radius
    right = (float(vx) + 0.5 * args_cli.track_width * float(wz)) / args_cli.wheel_radius
    target = torch.zeros((robot.num_instances, len(wheel_ids)), device=robot.device)
    target[:, 0] = left
    target[:, 1] = left
    target[:, 2] = right
    target[:, 3] = right
    robot.set_joint_velocity_target(target, joint_ids=wheel_ids)


def drive_to_pose(
    sim: SimulationContext,
    scene: InteractiveScene,
    robot: Articulation,
    wheel_ids: list[int],
    target_pose: tuple[float, float, float],
    locked_joint_target: torch.Tensor,
    tracker: Task319StateTracker,
) -> dict[str, Any]:
    sim_dt = sim.get_physics_dt()
    success = False
    final_dist = float("inf")
    final_yaw_error = float("inf")
    for step in range(args_cli.nav_max_steps_per_waypoint):
        root = robot.data.root_state_w[0].detach().cpu()
        x = float(root[0])
        y = float(root[1])
        yaw = yaw_from_quat_wxyz(root[3:7])
        dx = target_pose[0] - x
        dy = target_pose[1] - y
        final_dist = math.hypot(dx, dy)
        if final_dist > args_cli.nav_position_tolerance:
            desired_heading = math.atan2(dy, dx)
            heading_error = wrap_to_pi(desired_heading - yaw)
            if abs(heading_error) > 0.18:
                vx = 0.0
            else:
                vx = min(args_cli.nav_max_linear_speed, args_cli.nav_linear_gain * final_dist)
            wz = max(-args_cli.nav_max_angular_speed, min(args_cli.nav_max_angular_speed, args_cli.nav_angular_gain * heading_error))
        else:
            final_yaw_error = wrap_to_pi(target_pose[2] - yaw)
            vx = 0.0
            wz = max(-args_cli.nav_max_angular_speed, min(args_cli.nav_max_angular_speed, args_cli.nav_angular_gain * final_yaw_error))
            if abs(final_yaw_error) <= args_cli.nav_yaw_tolerance:
                success = True
                break
        hold_non_wheel_joints(robot, locked_joint_target, wheel_ids)
        apply_wheel_velocity(robot, wheel_ids, vx, wz)
        stabilize_robot_base_for_nav(robot)
        scene.write_data_to_sim()
        sim.step(render=True)
        scene.update(sim_dt)
        if step % 120 == 0:
            tracker.event("nav_progress", target_pose=target_pose, distance_m=final_dist, yaw_error_rad=final_yaw_error)
        tracker.tick()
    apply_wheel_velocity(robot, wheel_ids, 0.0, 0.0)
    return {"success": success, "target_pose": target_pose, "final_distance_m": final_dist, "final_yaw_error_rad": final_yaw_error}


def bin_y_for_category(category: str | None) -> float:
    return BIN_Y_BY_CATEGORY.get(canonical_category(category), BIN_Y_BY_CATEGORY["其他垃圾"])


def navigation_waypoints_to_bin(category: str | None) -> list[tuple[float, float, float]]:
    bin_y = bin_y_for_category(category)
    return [
        (TABLE_APPROACH_POSE[0], SIDE_CORRIDOR_Y, math.pi / 2.0),
        (BIN_DRIVE_X, SIDE_CORRIDOR_Y, 0.0),
        (BIN_DRIVE_X, bin_y, math.pi),
    ]


def navigation_waypoints_home() -> list[tuple[float, float, float]]:
    return [
        (BIN_DRIVE_X, SIDE_CORRIDOR_Y, math.pi / 2.0),
        (TABLE_APPROACH_POSE[0], SIDE_CORRIDOR_Y, math.pi),
        (TABLE_APPROACH_POSE[0], TABLE_APPROACH_POSE[1], TABLE_APPROACH_POSE[2]),
    ]


def drop_pose_for_category(selected: SelectedGrasp, category: str | None) -> np.ndarray:
    pose = np.array(selected.pose_world, dtype=np.float32).copy()
    pose[:3, 3] = np.array([3.03, bin_y_for_category(category), 0.95], dtype=np.float32)
    return pose


def execute_grasp(sim: SimulationContext, scene: InteractiveScene, selected: SelectedGrasp | None, cycle_dir: Path | None = None) -> dict[str, Any]:
    tracker = Task319StateTracker(sim.get_physics_dt(), sim.device)
    tracker.enter("REST", warp_enabled=tracker.warp_enabled)
    if selected is None:
        tracker.enter("RECOVER", reason="No selected grasp.")
        if cycle_dir is not None:
            (cycle_dir / "fsm_trace.json").write_text(json.dumps(tracker.trace, indent=2, ensure_ascii=False))
        return {"enabled": True, "success": False, "reason": "No selected grasp.", "fsm_trace": tracker.trace}
    robot: Articulation = scene["robot"]
    gripper = AttachedParallelGripper(robot)
    # The fallback grasp center is reliable, but its top-down orientation is
    # only a convention. Use 6D IK while preserving the wrist's current
    # orientation so the controller follows the same stable chain as the
    # isolated arm test instead of chasing a synthetic grasp frame.
    ik_cfg = DifferentialIKControllerCfg(command_type="pose", use_relative_mode=False, ik_method="dls")
    ik_controller = DifferentialIKController(ik_cfg, num_envs=scene.num_envs, device=sim.device)
    entity_cfg = SceneEntityCfg("robot", joint_names=[RIGHT_ARM_JOINT_EXPR], body_names=[RIGHT_EE_BODY])
    entity_cfg.resolve(scene)
    ee_body_id = entity_cfg.body_ids[0]
    # The base is physically locked during manipulation, so the right-arm
    # Jacobian must be indexed like a fixed-root chain. Using the floating-base
    # body index makes the differential IK step move in the wrong direction.
    ee_jacobi_idx = ee_body_id - 1
    initial_root_xy = robot.data.root_pos_w[:, 0:2].clone()
    locked_root_pose_w = robot.data.root_pose_w.clone()
    initial_z_by_key = {
        scene_key: float(scene[scene_key].data.root_state_w[0, 2].detach().cpu())
        for scene_key, _ in TRASH_SCENE_OBJECTS
        if scene_key in scene.keys()
    }
    target_center_w = selected.target.center_3d if selected.target is not None else selected.pose_world[:3, 3]
    target_scene_key, target_object_name, target_match_distance = locate_target_rigid_object(scene, target_center_w)
    target_initial_z = object_root_z(scene, target_scene_key)
    target_category = canonical_category(selected.target.waste_category if selected.target else None)

    tcp_grasp_pose = np.array(selected.pose_world, dtype=np.float32)
    tcp_pregrasp_pose = tcp_grasp_pose.copy()
    tcp_pregrasp_pose[:3, 3] -= tcp_grasp_pose[:3, :3] @ np.array([0.0, 0.0, args_cli.pregrasp_offset], dtype=np.float32)
    tcp_lift_pose = tcp_grasp_pose.copy()
    tcp_lift_pose[2, 3] += args_cli.lift_height
    wrist_rot_w = matrix_from_quat(robot.data.body_pose_w[:, ee_body_id, 3:7])[0].detach().cpu().numpy().astype(np.float32)
    grasp_pose = tcp_pose_to_wrist_pose(tcp_grasp_pose, wrist_rot_w)
    pregrasp_pose = tcp_pose_to_wrist_pose(tcp_pregrasp_pose, wrist_rot_w)
    lift_pose = tcp_pose_to_wrist_pose(tcp_lift_pose, wrist_rot_w)

    frame_marker_cfg = FRAME_MARKER_CFG.copy()
    frame_marker_cfg.markers["frame"].scale = (0.08, 0.08, 0.08)
    marker = VisualizationMarkers(frame_marker_cfg.replace(prim_path="/Visuals/selected_grasp_goal"))
    marker.visualize(torch.tensor(tcp_grasp_pose[:3, 3], device=robot.device).repeat(1, 1), torch.tensor(quat_wxyz_from_yaw(0.0), device=robot.device).repeat(1, 1))

    metrics: dict[str, Any] = {
        "enabled": True,
        "success": False,
        "grasp_success": False,
        "drop_success": False,
        "reason": "",
        "segments": [],
        "target_scene_key": target_scene_key,
        "target_object_name": target_object_name,
        "target_match_distance_m": target_match_distance,
        "target_category": target_category,
        "base_drift_m": 0.0,
        "lift_delta_m": 0.0,
        "best_lifted_scene_key": None,
        "navigation": [],
        "drop": None,
        "tcp_grasp_pose_world": tcp_grasp_pose.tolist(),
        "wrist_grasp_pose_world": grasp_pose.tolist(),
        "gripper_tcp_offset_m": GRIPPER_TCP_OFFSET_M.tolist(),
    }
    try:
        tracker.enter("BASE_TO_TABLE", mode="already_at_table")
        tracker.enter("STATIC_PERCEPT", camera_source="head_rgbd")
        tracker.enter("PLAN_GRASP", grasp_width_m=selected.width, grasp_score=selected.score, target_scene_key=target_scene_key)
        gripper.open_for_grasp(selected.width)
        tracker.enter("PRE_GRASP")
        metrics["segments"].append({"name": "pregrasp", **run_ik_segment(sim, scene, robot, ik_controller, entity_cfg, ee_body_id, ee_jacobi_idx, pregrasp_pose, args_cli.trajectory_steps, gripper=gripper, gripper_width=min(0.070, selected.width + 0.012), locked_root_pose_w=locked_root_pose_w)})
        metrics["segments"].append({"name": "grasp_pose", **run_ik_segment(sim, scene, robot, ik_controller, entity_cfg, ee_body_id, ee_jacobi_idx, grasp_pose, args_cli.trajectory_steps, gripper=gripper, gripper_width=min(0.070, selected.width + 0.006), locked_root_pose_w=locked_root_pose_w)})
        tracker.enter("GRASP")
        grasp_hold_joint_target = robot.data.joint_pos.clone()
        for _ in range(args_cli.grasp_steps):
            robot.set_joint_position_target(grasp_hold_joint_target)
            gripper.close()
            stabilize_robot_base(robot, locked_root_pose_w)
            scene.write_data_to_sim()
            sim.step(render=True)
            scene.update(sim.get_physics_dt())
            tracker.tick()
        tracker.enter("LIFT")
        metrics["segments"].append({"name": "lift", **run_ik_segment(sim, scene, robot, ik_controller, entity_cfg, ee_body_id, ee_jacobi_idx, lift_pose, args_cli.lift_steps, gripper=gripper, gripper_width=0.0, locked_root_pose_w=locked_root_pose_w)})
        tracker.enter("VERIFY_HOLD")
        lift_hold_joint_target = robot.data.joint_pos.clone()
        for _ in range(args_cli.hold_steps):
            robot.set_joint_position_target(lift_hold_joint_target)
            gripper.close()
            stabilize_robot_base(robot, locked_root_pose_w)
            scene.write_data_to_sim()
            sim.step(render=True)
            scene.update(sim.get_physics_dt())
            tracker.tick()
        base_drift = float(torch.linalg.norm(robot.data.root_pos_w[:, 0:2] - initial_root_xy, dim=1).max().item())
        target_final_z = object_root_z(scene, target_scene_key)
        target_delta = float(target_final_z - target_initial_z) if target_final_z is not None and target_initial_z is not None else 0.0
        best_lifted_key, best_lift_delta = lifted_object_delta(scene, initial_z_by_key)
        lift_delta = max(target_delta, best_lift_delta)
        metrics["base_drift_m"] = base_drift
        metrics["lift_delta_m"] = lift_delta
        metrics["best_lifted_scene_key"] = best_lifted_key
        metrics["grasp_success"] = lift_delta >= 0.05
        metrics["success"] = metrics["grasp_success"]
        metrics["reason"] = "Object lifted and held." if metrics["grasp_success"] else "No object was verified above the table after lift."
        tracker.event(
            "verify_lift",
            grasp_success=metrics["grasp_success"],
            target_delta_m=target_delta,
            best_lift_delta_m=best_lift_delta,
            best_lifted_scene_key=best_lifted_key,
            base_drift_m=base_drift,
        )
        if metrics["grasp_success"] and args_cli.enable_sort_nav:
            tracker.enter("NAV_TO_BIN", category=target_category, bin_name=BIN_NAME_BY_CATEGORY.get(target_category, "other"))
            wheel_ids, wheel_names = robot.find_joints(WHEEL_JOINTS, preserve_order=True)
            wheel_id_list = [int(item) for item in wheel_ids]
            if len(wheel_ids) != 4:
                metrics["navigation"].append({"success": False, "reason": f"Expected 4 wheel joints, got {wheel_names}."})
            else:
                nav_hold_target = robot.data.joint_pos.clone()
                for waypoint in navigation_waypoints_to_bin(target_category):
                    result = drive_to_pose(sim, scene, robot, wheel_id_list, waypoint, nav_hold_target, tracker)
                    metrics["navigation"].append(result)
                    if not result["success"]:
                        break
                if all(item.get("success", False) for item in metrics["navigation"]):
                    tracker.enter("DROP", category=target_category)
                    drop_pose = tcp_pose_to_wrist_pose(drop_pose_for_category(selected, target_category))
                    current_root_pose = robot.data.root_pose_w.clone()
                    drop_segment = run_ik_segment(
                        sim,
                        scene,
                        robot,
                        ik_controller,
                        entity_cfg,
                        ee_body_id,
                        ee_jacobi_idx,
                        drop_pose,
                        args_cli.trajectory_steps,
                        gripper=gripper,
                        gripper_width=0.0,
                        locked_root_pose_w=current_root_pose,
                    )
                    for _ in range(args_cli.drop_steps):
                        robot.set_joint_position_target(robot.data.joint_pos.clone())
                        gripper.set_width(0.070)
                        stabilize_robot_base(robot, current_root_pose)
                        scene.write_data_to_sim()
                        sim.step(render=True)
                        scene.update(sim.get_physics_dt())
                        tracker.tick()
                    dropped_z = object_root_z(scene, target_scene_key)
                    metrics["drop"] = {"segment": drop_segment, "object_z_after_drop": dropped_z}
                    metrics["drop_success"] = True
                    tracker.enter("RETURN_HOME")
                    return_hold_target = robot.data.joint_pos.clone()
                    for waypoint in navigation_waypoints_home():
                        result = drive_to_pose(sim, scene, robot, wheel_id_list, waypoint, return_hold_target, tracker)
                        metrics["navigation"].append({"return": True, **result})
                        if not result["success"]:
                            break
        tracker.enter("DONE" if metrics["success"] else "RECOVER", reason=metrics["reason"])
    except Exception as exc:
        metrics["success"] = False
        metrics["grasp_success"] = False
        metrics["reason"] = repr(exc)
        tracker.enter("RECOVER", reason=repr(exc))
    metrics["fsm_trace"] = tracker.trace
    if cycle_dir is not None:
        (cycle_dir / "fsm_trace.json").write_text(json.dumps(tracker.trace, indent=2, ensure_ascii=False))
    return metrics


def apply_ycb_visual_runtime_physics() -> None:
    from pxr import Usd

    stage = sim_utils.get_current_stage()
    convex_cfg = sim_utils.ConvexHullPropertiesCfg(hull_vertex_limit=64)
    collider_cfg = collision_props(contact_offset=0.002)
    for env_id in range(args_cli.num_envs):
        for name, mass in YCB_VISUAL_RUNTIME_MASSES.items():
            root_path = f"/World/envs/env_{env_id}/{name}"
            root_prim = stage.GetPrimAtPath(root_path)
            if not root_prim.IsValid():
                continue
            sim_utils.define_rigid_body_properties(root_path, rigid_props(), stage=stage)
            sim_utils.define_mass_properties(root_path, sim_utils.MassPropertiesCfg(mass=mass), stage=stage)
            for prim in Usd.PrimRange(root_prim):
                if prim.GetTypeName() != "Mesh":
                    continue
                mesh_path = str(prim.GetPath())
                sim_utils.define_collision_properties(mesh_path, collider_cfg, stage=stage)
                sim_utils.modify_mesh_collision_properties(mesh_path, convex_cfg, stage=stage)


def apply_gripper_contact_material() -> None:
    from pxr import Usd, UsdPhysics

    stage = sim_utils.get_current_stage()
    material_path = "/World/physicsScene/task319_gripper_rubber"
    material_cfg = sim_utils.RigidBodyMaterialCfg(
        static_friction=1.9,
        dynamic_friction=1.45,
        restitution=0.0,
        friction_combine_mode="max",
        restitution_combine_mode="min",
    )
    material_cfg.func(material_path, material_cfg)
    name_tokens = ("gripper_base", "left_finger", "right_finger")
    for env_id in range(args_cli.num_envs):
        root_prim = stage.GetPrimAtPath(f"/World/envs/env_{env_id}/Kuavo62")
        if not root_prim.IsValid():
            continue
        for prim in Usd.PrimRange(root_prim):
            prim_path = str(prim.GetPath())
            if any(token in prim_path for token in name_tokens) and not prim.IsInstanceProxy() and prim.HasAPI(UsdPhysics.CollisionAPI):
                sim_utils.bind_physics_material(prim_path, material_path, stage=stage)


def write_cycle(sim: SimulationContext, scene: InteractiveScene, run_dir: Path, cycle_index: int) -> bool:
    cycle_dir = run_dir / f"cycle_{cycle_index:04d}"
    cycle_dir.mkdir(parents=True, exist_ok=True)
    rgb, depth_m, intrinsics, t_camera_to_world = capture_head_camera(scene)
    Image.fromarray(rgb).save(cycle_dir / "head_rgb.png")
    save_depth_images(depth_m, cycle_dir)
    instances = run_yolo(rgb, cycle_dir)
    depth_instances = detect_tabletop_depth_components(scene, rgb, depth_m, intrinsics, t_camera_to_world, cycle_dir) if args_cli.use_centroid_fallback else []
    instances.extend(depth_instances)
    classify_instances(rgb, instances, cycle_dir)
    for inst in instances:
        points_world = mask_points_world(inst.mask, depth_m, intrinsics, t_camera_to_world)
        if points_world.shape[0] > 0:
            inst.center_3d = np.median(points_world, axis=0).astype(np.float32)
    target, target_reason = choose_target(instances)
    selected, graspnet_meta = run_graspnet_for_target(rgb, depth_m, intrinsics, t_camera_to_world, target, cycle_dir)
    execution_meta = {"enabled": False}
    if args_cli.execute_grasp:
        execution_meta = execute_grasp(sim, scene, selected, cycle_dir)
    metadata = {
        "cycle_index": cycle_index,
        "camera_source": "head_rgbd",
        "intrinsics": intrinsics.tolist(),
        "camera_to_world": t_camera_to_world.tolist(),
        "rgb_shape": list(rgb.shape),
        "depth_shape": list(depth_m.shape),
        "yolo_instance_count": len(instances),
        "target_selection": {
            "reason": target_reason,
            "selected_yolo_index": target.index if target else None,
            "source": target.source if target else None,
            "scene_key": target.scene_key if target else None,
            "scene_object_name": target.scene_object_name if target else None,
            "object_name": target.vlm.object_name if target and target.vlm else None,
            "waste_category": target.vlm.waste_category if target and target.vlm else None,
            "vlm_confidence": target.vlm.confidence if target and target.vlm else None,
            "mask_pixels": int(target.mask.sum()) if target else 0,
            "center_3d_world": target.center_3d.tolist() if target is not None and target.center_3d is not None else None,
        },
        "depth_component_count": len(depth_instances),
        "graspnet": graspnet_meta,
        "execution": execution_meta,
    }
    (cycle_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False))
    (run_dir / "latest_cycle.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False))
    print(
        f"[INFO] Saved cycle {cycle_index:04d}: camera=head_rgbd "
        f"yolo={len(instances)} target={metadata['target_selection']['object_name']} "
        f"graspnet={graspnet_meta.get('filtered_count', 0)}/{graspnet_meta.get('candidate_count', 0)} "
        f"execute={execution_meta.get('success', False)} -> {cycle_dir}",
        flush=True,
    )
    return bool(args_cli.execute_grasp)


def run_loop(sim: SimulationContext, scene: InteractiveScene, run_dir: Path) -> None:
    robot: Articulation = scene["robot"]
    sim_dt = sim.get_physics_dt()
    reset_scene(scene)
    for _ in range(args_cli.warmup_steps):
        stabilize_robot_base(robot)
        scene.write_data_to_sim()
        sim.step(render=True)
        scene.update(sim_dt)
    cycle = 0
    steps_since_capture = args_cli.cycle_interval_steps
    while simulation_app.is_running():
        stabilize_robot_base(robot)
        scene.write_data_to_sim()
        sim.step(render=True)
        scene.update(sim_dt)
        steps_since_capture += 1
        if steps_since_capture >= args_cli.cycle_interval_steps:
            should_stop = write_cycle(sim, scene, run_dir, cycle)
            cycle += 1
            steps_since_capture = 0
            if should_stop or (args_cli.num_cycles > 0 and cycle >= args_cli.num_cycles):
                break


def main() -> None:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = (WORKSPACE_ROOT / args_cli.output_dir / timestamp).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    sim_cfg = sim_utils.SimulationCfg(device=args_cli.device, dt=1.0 / 120.0, physics_material=high_friction_material())
    sim = SimulationContext(sim_cfg)
    sim.set_camera_view([3.3, -2.8, 2.2], [1.35, 0.0, 0.9])
    scene = InteractiveScene(HeadCameraGraspSceneCfg(num_envs=args_cli.num_envs, env_spacing=4.0, replicate_physics=False))
    apply_ycb_visual_runtime_physics()
    apply_gripper_contact_material()
    sim.reset()
    print(f"[INFO] Recording head-camera visual grasp chain to: {run_dir}", flush=True)
    print("[INFO] Camera source is fixed to scene['head_rgbd']; YOLO labels are weak and VLM provides object/category labels.", flush=True)
    run_loop(sim, scene, run_dir)


if __name__ == "__main__":
    main()
    simulation_app.close()
