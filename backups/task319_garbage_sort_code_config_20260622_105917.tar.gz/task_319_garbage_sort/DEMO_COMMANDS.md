# Task 319 Demo Commands

All commands below use the required `my_task319_safe` environment. Run them from:

```bash
cd /home/zhxm/workspace/mda_isaaclab
```

Documentation rule:
- Every task-319 code change should update `task_319_garbage_sort/CHANGELOG.md`.
- Any visible behavior change should also add or update the launch/display command in this file.

## 1. Visual Scene Preview: robot + table + 10 textured YCB trash objects

This opens Isaac Sim with the phase-one scene. You should see Kuavo in the URDF zero upright posture, the table, four open bins, and 10 correctly-scaled textured YCB objects on the table.

```bash
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/phase1_scene_ros2_bridge.py --disable_lidar
```

Notes:
- Do not pass `--headless` if you want to see the window.
- Kuavo's default `knee_joint`, `leg_joint`, `waist_pitch_joint`, `waist_yaw_joint`, `zhead_1_joint`, and `zhead_2_joint` are all `0.0`.
- This script is a scene/ROS bridge entrypoint; it does not perform grasping by itself.
- Add `--ros2` only when you want `/cmd_vel`, `/odom`, `/scan`, and `/tf`.

## 2. Visible Gripper Physics Demo: attached gripper closes on a red block

This opens Isaac Sim close to the wrist gripper. The robot uses the URDF zero upright posture while the gripper stays open first, then a small red block appears between the finger pads, the gripper closes, and the block remains held.

```bash
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/gripper_physics_test.py --smoke_steps 0 --close_start_step 600
```

Expected visual sequence:
- First ~5 seconds: gripper open.
- Then: red block is inserted between the fingers.
- Then: fingers close and hold the block.

For a headless metric check instead of visual observation:

```bash
timeout 120s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/gripper_physics_test.py --headless --smoke_steps 180
```

## 3. Visible Manipulation-Control Demo: fixed-base arm tracks a smooth target

This opens Isaac Sim with only the robot in an empty scene. The robot starts from the URDF zero upright posture, the base is fixed/locked, navigation is disabled, and the right arm follows a smooth 6D target. Frame markers show current and target end-effector poses.

```bash
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/arm_chain_isolated_test.py --smoke_steps 0 --trajectory_steps 720
```

Expected visual sequence:
- Base does not drift.
- Right arm moves smoothly toward the target marker.
- No navigation or obstacle variables are involved.

For a headless metric check:

```bash
timeout 160s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/arm_chain_isolated_test.py --headless --smoke_steps 360
```

## 4. True Grasp State Machine: head RGB-D perception + lift verification

This is the current Task319 main chain. It starts from the phase-one scene style, places Kuavo near the table, uses only the robot head RGB-D camera for perception, chooses a tabletop object, executes the right-arm/gripper state machine, and verifies success by reading the real simulated object pose.

Headless true-grasp acceptance command:

```bash
timeout 300s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/task319_grasp_sort_sm.py --headless --num_cycles 1 --execute_grasp --skip_vlm --skip_graspnet --use_centroid_fallback --target_object_name potted --record_debug --warmup_steps 80 --cycle_interval_steps 1 --trajectory_steps 420 --grasp_steps 130 --lift_steps 240 --hold_steps 180 --max_joint_step 0.025
```

Expected result:
- Kuavo stays upright with fixed-base manipulation and `base_drift_m` near `0.0`.
- The target object is lifted more than `0.05 m` above the table and held through `VERIFY_HOLD`.
- `metadata.json` reports `execution.grasp_success: true` and records IK segment errors, lift delta, selected target, and camera source.

GUI true-grasp command with GLM-VLM:

```bash
export GLM_API_KEY='your GLM API key'
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/task319_grasp_sort_sm.py --num_cycles 1 --execute_grasp --record_debug --vlm_model glm-5v-turbo --use_centroid_fallback
```

GUI grasp + experimental bin-drop navigation:

```bash
export GLM_API_KEY='your GLM API key'
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/task319_grasp_sort_sm.py --num_cycles 1 --execute_grasp --enable_sort_nav --record_debug --vlm_model glm-5v-turbo --use_centroid_fallback
```

Notes:
- `--enable_sort_nav` uses conservative internal waypoints to the hardcoded bin positions. Keep it off when validating grasp alone.
- API keys must stay in environment variables: `GLM_API_KEY`, `ZHIPUAI_API_KEY`, or `BIGMODEL_API_KEY`.
- The latest verified headless run lifted `trash_potted_meat_can_0` by `0.228 m` with `base_drift_m = 0.000 m`.

Each cycle writes:

```text
task_319_garbage_sort/output/head_camera_grasp_records/<timestamp>/cycle_0000/
  head_rgb.png
  head_depth_mm.png
  head_depth_vis.png
  head_depth_m.npy
  yolo_overlay.png
  yolo_union_mask.png
  yolo_instances.json
  depth_component_overlay.png
  depth_components.json
  vlm_overlay.png
  vlm_results.json
  target_mask.png
  graspnet_workspace_mask.png
  graspnet_overlay.png
  selected_grasp_overlay.png
  fsm_trace.json
  metadata.json
```

## 5. Head-Camera YOLO / GLM-VLM / GraspNet Recording Demo

This opens the phase-one style scene with Kuavo standing near the table in the URDF zero upright posture. The entire vision and grasp chain is sourced from the robot head RGB-D camera at `Kuavo62/head_camera_depth/head_rgbd`: YOLO provides instance masks, GLM-VLM names and classifies each masked object, GraspNet proposes grasps on the selected mask, and `--execute_grasp` runs the right-arm/gripper chain. It does not navigate to bins yet.

GUI repeat mode for visual inspection:

```bash
export GLM_API_KEY='your GLM API key'
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_record_demo.py --num_cycles 0 --cycle_interval_steps 240 --vlm_model glm-5v-turbo
```

One visible grasp attempt:

```bash
export GLM_API_KEY='your GLM API key'
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_record_demo.py --num_cycles 1 --execute_grasp --vlm_model glm-5v-turbo --graspnet_num_point 8000
```

Headless one-cycle verification:

```bash
export GLM_API_KEY='your GLM API key'
timeout 180s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_record_demo.py --headless --num_cycles 1 --warmup_steps 80 --cycle_interval_steps 30 --vlm_model glm-5v-turbo --graspnet_num_point 4096
```

Fast RGB-D + YOLO check without network/API calls:

```bash
timeout 120s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_record_demo.py --headless --num_cycles 1 --skip_vlm --skip_graspnet
```

Each cycle writes:

```text
task_319_garbage_sort/output/head_camera_grasp_records/<timestamp>/cycle_0000/
  head_rgb.png
  head_depth_mm.png
  head_depth_vis.png
  head_depth_m.npy
  yolo_overlay.png
  yolo_union_mask.png
  yolo_instances.json
  depth_component_overlay.png
  depth_components.json
  vlm_overlay.png
  vlm_results.json
  target_mask.png
  graspnet_workspace_mask.png
  graspnet_overlay.png
  selected_grasp_overlay.png
  metadata.json
```

Notes:
- `--num_cycles 0` means repeat until you close Isaac Sim.
- Do not write the GLM API key into tracked files. Keep it in `GLM_API_KEY`, `ZHIPUAI_API_KEY`, or `BIGMODEL_API_KEY`.
- `metadata.json` records `camera_source: head_rgbd`, camera intrinsics/extrinsics, VLM classifications, target selection, GraspNet status, and execution status.
- The old dry-run below is only a terminal pipeline check; use this recording demo when you want the actual head-camera images.

## 6. Perception / Grasp Planning Dry-Run

This does not open Isaac Sim. It verifies target selection, waste classification, mask filtering, and grasp selection.

```bash
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_pipeline.py --dry_run_graspnet
```

## 7. Dependency / Model Check

This confirms GraspNet, YOLO, CUDA extensions, and optional LLM dependencies are present.

```bash
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/scripts/prepare_grasp_deps.py
```
