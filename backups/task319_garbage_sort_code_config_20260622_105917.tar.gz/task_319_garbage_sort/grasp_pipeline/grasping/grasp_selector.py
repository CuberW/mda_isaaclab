"""Select a physically reasonable target-object grasp."""

from __future__ import annotations

import numpy as np

from task_319_garbage_sort.grasp_pipeline.grasping.mask_filter import clamp_width
from task_319_garbage_sort.grasp_pipeline.types import GraspCandidates, PerceivedObject, SelectedGrasp


def select_best_grasp(
    candidates: GraspCandidates,
    target: PerceivedObject,
    *,
    t_camera_to_world: np.ndarray | None = None,
    table_surface_z: float = 0.81,
    max_width_m: float = 0.070,
    top_k: int = 20,
) -> SelectedGrasp | None:
    if len(candidates.scores) == 0:
        return None
    order = np.argsort(candidates.scores)[::-1][: min(top_k, len(candidates.scores))]
    target_center = target.center_3d
    best_idx = int(order[0])
    best_score = -np.inf
    for idx in order:
        pose = np.array(candidates.poses[idx], dtype=np.float32)
        pose_world = t_camera_to_world @ pose if t_camera_to_world is not None else pose
        if pose_world[2, 3] < table_surface_z + 0.015:
            continue
        approach_dir = pose_world[:3, 2]
        approach_norm = np.linalg.norm(approach_dir)
        if approach_norm > 0.0:
            approach_dir = approach_dir / approach_norm
        top_down_bonus = max(0.0, float(np.dot(approach_dir, np.array([0.0, 0.0, -1.0]))))
        centrality = 0.0
        if target_center is not None:
            dist = float(np.linalg.norm(pose_world[:3, 3] - target_center))
            centrality = max(0.0, 1.0 - dist / 0.15)
        combined = float(candidates.scores[idx]) * 0.62 + top_down_bonus * 0.28 + centrality * 0.10
        if combined > best_score:
            best_score = combined
            best_idx = int(idx)
    selected_pose = np.array(candidates.poses[best_idx], dtype=np.float32)
    selected_pose_world = t_camera_to_world @ selected_pose if t_camera_to_world is not None else selected_pose
    return SelectedGrasp(
        pose_world=selected_pose_world,
        width=clamp_width(float(candidates.widths[best_idx]), max_width=max_width_m),
        score=float(candidates.scores[best_idx]),
        center_2d=(float(candidates.centers_2d[best_idx, 0]), float(candidates.centers_2d[best_idx, 1])),
        target=target,
    )
