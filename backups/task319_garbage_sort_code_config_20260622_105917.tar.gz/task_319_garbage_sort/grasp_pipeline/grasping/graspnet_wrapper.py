"""Thin wrapper around the local graspnet-baseline checkout."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from task_319_garbage_sort.grasp_pipeline.types import GraspCandidates


class GraspNetWrapper:
    """Lazy GraspNet baseline loader.

    The heavy dependencies are imported only when inference is requested so that
    unit tests for filtering and control can run without CUDA/Open3D.
    """

    def __init__(
        self,
        repo_root: Path,
        checkpoint_path: Path,
        *,
        num_point: int = 20000,
        num_view: int = 300,
        collision_thresh: float = 0.01,
        voxel_size: float = 0.01,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.checkpoint_path = checkpoint_path.resolve()
        self.num_point = num_point
        self.num_view = num_view
        self.collision_thresh = collision_thresh
        self.voxel_size = voxel_size
        self._net = None

    def _add_paths(self) -> None:
        for rel in ("models", "dataset", "utils", "pointnet2"):
            path = str(self.repo_root / rel)
            if path not in sys.path:
                sys.path.insert(0, path)
        api_path = str(self.repo_root.parent / "graspnetAPI")
        if api_path not in sys.path:
            sys.path.insert(0, api_path)

    def load(self):
        if self._net is not None:
            return self._net
        if not self.checkpoint_path.is_file():
            raise FileNotFoundError(f"GraspNet checkpoint not found: {self.checkpoint_path}")
        self._add_paths()
        import torch
        from graspnet import GraspNet

        net = GraspNet(
            input_feature_dim=0,
            num_view=self.num_view,
            num_angle=12,
            num_depth=4,
            cylinder_radius=0.05,
            hmin=-0.02,
            hmax_list=[0.01, 0.02, 0.03, 0.04],
            is_training=False,
        )
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        net.to(device)
        checkpoint = torch.load(self.checkpoint_path, map_location=device)
        net.load_state_dict(checkpoint["model_state_dict"])
        net.eval()
        self._net = net
        return net

    def detect(self, rgb: np.ndarray, depth_m: np.ndarray, intrinsics: np.ndarray, workspace_mask: np.ndarray) -> GraspCandidates:
        """Run GraspNet and return candidates in the camera frame."""

        self._add_paths()
        import torch
        from collision_detector import ModelFreeCollisionDetector
        from data_utils import CameraInfo, create_point_cloud_from_depth_image
        from graspnet import pred_decode
        from graspnetAPI import GraspGroup

        net = self.load()
        height, width = depth_m.shape[:2]
        camera = CameraInfo(width, height, intrinsics[0, 0], intrinsics[1, 1], intrinsics[0, 2], intrinsics[1, 2], 1.0)
        cloud = create_point_cloud_from_depth_image(depth_m.astype(np.float32), camera, organized=True)
        valid = workspace_mask.astype(bool) & np.isfinite(depth_m) & (depth_m > 0.0)
        cloud_masked = cloud[valid]
        if len(cloud_masked) == 0:
            return GraspCandidates(np.empty((0, 4, 4)), np.empty((0,)), np.empty((0,)), np.empty((0, 2)))
        if len(cloud_masked) >= self.num_point:
            indices = np.random.choice(len(cloud_masked), self.num_point, replace=False)
        else:
            indices = np.concatenate(
                [np.arange(len(cloud_masked)), np.random.choice(len(cloud_masked), self.num_point - len(cloud_masked), replace=True)]
            )
        device = next(net.parameters()).device
        end_points = {"point_clouds": torch.from_numpy(cloud_masked[indices][None].astype(np.float32)).to(device)}
        with torch.no_grad():
            end_points = net(end_points)
            grasp_preds = pred_decode(end_points)
        grasp_group = GraspGroup(grasp_preds[0].detach().cpu().numpy())
        if self.collision_thresh > 0.0:
            detector = ModelFreeCollisionDetector(cloud_masked, voxel_size=self.voxel_size)
            collision_mask = detector.detect(grasp_group, approach_dist=0.05, collision_thresh=self.collision_thresh)
            grasp_group = grasp_group[~collision_mask]
        grasp_group.nms()
        grasp_group.sort_by_score()
        translations = grasp_group.translations
        rotations = grasp_group.rotation_matrices
        poses = np.repeat(np.eye(4, dtype=np.float32)[None], len(grasp_group), axis=0)
        poses[:, :3, :3] = rotations
        poses[:, :3, 3] = translations
        centers_2d = _project_points(translations, intrinsics)
        return GraspCandidates(poses=poses, scores=grasp_group.scores, widths=grasp_group.widths, centers_2d=centers_2d)


def _project_points(points_camera: np.ndarray, intrinsics: np.ndarray) -> np.ndarray:
    z = np.maximum(points_camera[:, 2], 1e-6)
    u = intrinsics[0, 0] * points_camera[:, 0] / z + intrinsics[0, 2]
    v = intrinsics[1, 1] * points_camera[:, 1] / z + intrinsics[1, 2]
    return np.stack([u, v], axis=1).astype(np.float32)
