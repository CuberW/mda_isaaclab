"""Mask-based filtering for full-image grasp candidates."""

from __future__ import annotations

import numpy as np

from task_319_garbage_sort.grasp_pipeline.types import GraspCandidates


def erode_mask(mask: np.ndarray, margin: int = 5) -> np.ndarray:
    """Binary erosion implemented with NumPy to avoid a hard OpenCV dependency."""

    mask = mask.astype(bool)
    if margin <= 1:
        return mask
    pad = margin // 2
    padded = np.pad(mask, pad, mode="constant", constant_values=False)
    eroded = np.ones_like(mask, dtype=bool)
    for dy in range(margin):
        for dx in range(margin):
            eroded &= padded[dy : dy + mask.shape[0], dx : dx + mask.shape[1]]
    return eroded


def filter_grasps_by_mask(candidates: GraspCandidates, object_mask: np.ndarray, margin: int = 5) -> GraspCandidates:
    eroded = erode_mask(object_mask, margin)
    valid_indices: list[int] = []
    height, width = eroded.shape[:2]
    for idx, (u, v) in enumerate(candidates.centers_2d):
        ui = int(round(float(u)))
        vi = int(round(float(v)))
        if 0 <= ui < width and 0 <= vi < height and eroded[vi, ui]:
            valid_indices.append(idx)
    indices = np.asarray(valid_indices, dtype=np.int64)
    return GraspCandidates(
        poses=candidates.poses[indices],
        scores=candidates.scores[indices],
        widths=candidates.widths[indices],
        centers_2d=candidates.centers_2d[indices],
    )


def clamp_width(width: float, min_width: float = 0.0, max_width: float = 0.070) -> float:
    return float(np.clip(width, min_width, max_width))
