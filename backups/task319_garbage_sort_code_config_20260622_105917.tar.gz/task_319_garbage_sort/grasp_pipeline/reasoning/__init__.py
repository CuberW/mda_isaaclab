"""Waste-category reasoning backends."""

