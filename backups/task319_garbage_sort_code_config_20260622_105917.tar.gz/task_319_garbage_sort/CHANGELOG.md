# Task 319 Change Log

All implementation changes for this task should be documented here together with the command that demonstrates the changed behavior.

## 2026-06-22: Local Git snapshot hygiene

Change:
- Added `.gitignore` for the Task319 snapshot repository.
- Added `SAVE_TO_GITHUB.md` with GitHub push commands for user `CuberW <773329413@qq.com>`.
- Ignored generated outputs, Python caches, downloaded model weights, and third-party dependency folders so the code/config snapshot stays small and safe to push.

## 2026-06-22: True head-camera grasp state machine

Change:
- Added the public main-chain entrypoint `task319_grasp_sort_sm.py` for Task319 grasp/sort execution.
- Extended the head-camera grasp chain into an FSM: `REST -> BASE_TO_TABLE -> STATIC_PERCEPT -> PLAN_GRASP -> PRE_GRASP -> GRASP -> LIFT -> VERIFY_HOLD`, with optional `NAV_TO_BIN -> DROP -> RETURN_HOME`.
- Kept perception grounded in the robot head RGB-D camera only. Debug output now records head RGB/depth, YOLO masks, VLM overlay, depth-component fallback, selected grasp overlay, FSM trace, and execution metrics.
- Added a tabletop depth-component fallback so YCB objects can still be selected from the head RGB-D point cloud when YOLO labels are unreliable.
- Fixed true-grasp manipulation stability by using fixed-base manipulation by default, keeping Kuavo upright at the URDF zero pose, locking the base during arm execution, and preserving the current wrist orientation for reachable pose-IK commands.
- Left hardcoded bin-waypoint sorting behind `--enable_sort_nav`; the default command stops after successful lift/hold so grasp can be accepted independently before navigation is enabled.

Syntax check:

```bash
cd /home/zhxm/workspace/mda_isaaclab
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python -m py_compile task_319_garbage_sort/visual_grasp_record_demo.py task_319_garbage_sort/task319_grasp_sort_sm.py
```

Headless true-grasp verification command:

```bash
cd /home/zhxm/workspace/mda_isaaclab
timeout 300s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/task319_grasp_sort_sm.py --headless --num_cycles 1 --execute_grasp --skip_vlm --skip_graspnet --use_centroid_fallback --target_object_name potted --record_debug --warmup_steps 80 --cycle_interval_steps 1 --trajectory_steps 420 --grasp_steps 130 --lift_steps 240 --hold_steps 180 --max_joint_step 0.025
```

Observed result from `output/head_camera_grasp_records/20260622_033759/cycle_0000/metadata.json`:
- Selected target: `trash_potted_meat_can_0`, category `厨余垃圾`, source `depth_component`, camera source `head_rgbd`.
- IK final position errors: pre-grasp `0.016 m`, grasp `0.016 m`, lift `0.049 m`.
- Lift success: `grasp_success=true`, target lift delta `0.228 m`, base drift `0.000 m`.
- Debug files include `head_rgb.png`, `head_depth_vis.png`, `yolo_overlay.png`, `vlm_overlay.png`, `depth_component_overlay.png`, `selected_grasp_overlay.png`, `fsm_trace.json`, and `metadata.json`.

GUI true-grasp command:

```bash
cd /home/zhxm/workspace/mda_isaaclab
export GLM_API_KEY='your GLM API key'
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/task319_grasp_sort_sm.py --num_cycles 1 --execute_grasp --record_debug --vlm_model glm-5v-turbo --use_centroid_fallback
```

## 2026-06-22: Kuavo default upright posture

Change:
- Restored Kuavo's default posture to the URDF zero pose in the scene preview, head-camera grasp demo, isolated arm test, and gripper physics test.
- Set the robot root z height to `0.0` for wheel-ground contact instead of lifting the base.
- Kept head-camera table visibility through `CameraCfg.OffsetCfg`, not through non-zero torso or head joint defaults.

Display command:

```bash
cd /home/zhxm/workspace/mda_isaaclab
/home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/phase1_scene_ros2_bridge.py --disable_lidar
```

Head-camera verification command:

```bash
cd /home/zhxm/workspace/mda_isaaclab
timeout 120s /home/zhxm/miniconda3/envs/my_task319_safe/bin/python task_319_garbage_sort/visual_grasp_record_demo.py --headless --num_cycles 1 --skip_vlm --skip_graspnet
```

Expected result:
- Kuavo stands in the URDF zero upright posture, with `knee_joint`, `leg_joint`, `waist_pitch_joint`, `waist_yaw_joint`, `zhead_1_joint`, and `zhead_2_joint` at `0.0`.
- The head camera still records `head_rgb.png`, `head_depth_vis.png`, `yolo_overlay.png`, and `metadata.json`.
